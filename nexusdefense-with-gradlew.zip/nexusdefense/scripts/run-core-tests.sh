#!/bin/sh
# Minecraft/Forge/Gradle 不要で core 層(純Java)の検証を実行する。 要: JDK 17+
set -e
cd "$(dirname "$0")/.."
rm -rf build/core && mkdir -p build/core
if command -v javac >/dev/null 2>&1; then JC=javac; else JC="java -m jdk.compiler/com.sun.tools.javac.Main"; fi
$JC -encoding UTF-8 -d build/core $(find src/main/java/com/nexusdefense/core src/test/java -name '*.java')
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp build/core com.nexusdefense.core.CoreTests
