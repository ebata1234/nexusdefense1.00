#!/usr/bin/env python3
"""登録ID(Javaソース) <-> アセット(JSON/PNG/lang) の配線監査。Minecraft実機の代わりにファイル整合を検査する。"""
import json, re, os, glob, sys
from PIL import Image

ROOT = os.path.join(os.path.dirname(__file__), '..')
A = f'{ROOT}/src/main/resources/assets/nexusdefense'
J = f'{ROOT}/src/main/java/com/nexusdefense'
ok = bad = 0
def check(name, cond, detail=''):
    global ok, bad
    if cond: ok += 1
    else: bad += 1; print('  NG  ' + name + (' :: ' + detail if detail else ''))

def strs(path, var):
    src = open(path, encoding='utf-8').read()
    m = re.search(var + r'\s*=\s*List\.of\((.*?)\);', src, re.S)
    return re.findall(r'"([a-z_]+)"', m.group(1))

block_ids = strs(f'{J}/game/registry/ModBlocks.java', 'IDS')
item_ids = strs(f'{J}/game/registry/ModItems.java', 'PLAIN_IDS')
mob_src = open(f'{J}/game/MobSpec.java', encoding='utf-8').read()
mob_ids = re.findall(r'new MobSpec\("([a-z_]+)"', mob_src)
lang = {l: json.load(open(f'{A}/lang/{l}.json', encoding='utf-8')) for l in ('en_us', 'ja_jp')}
print(f'登録ID: blocks={len(block_ids)} plain_items={len(item_ids)} mobs={len(mob_ids)}')

def tex_exists(ref):
    ns, path = ref.split(':') if ':' in ref else ('minecraft', ref)
    if ns != 'nexusdefense': return True          # バニラ参照は対象外
    return os.path.exists(f'{A}/textures/{path}.png')

def model_textures(model_ref, seen=None):
    """モデルJSONが参照する全テクスチャ(parent連鎖含む)。"""
    ns, path = model_ref.split(':') if ':' in model_ref else ('minecraft', model_ref)
    if ns != 'nexusdefense': return []
    d = json.load(open(f'{A}/models/{path}.json', encoding='utf-8'))
    refs = list(d.get('textures', {}).values())
    if 'parent' in d: refs += model_textures(d['parent'])
    for el in d.get('elements', []):
        for f in el['faces'].values():
            t = f['texture']
            if not t.startswith('#'): refs.append(t)
            else:
                key = t[1:]
                check(f'{model_ref}: テクスチャ変数 {t} が定義済み', key in d.get('textures', {}), t)
    return refs

print('\n[ブロック]')
for b in block_ids:
    bs = f'{A}/blockstates/{b}.json'
    check(f'{b}: blockstate あり', os.path.exists(bs))
    if os.path.exists(bs):
        mdl = json.load(open(bs))['variants']['']['model']
        check(f'{b}: blockstate→{mdl} のモデルあり', os.path.exists(f"{A}/models/{mdl.split(':')[1]}.json"))
        for t in model_textures(mdl): check(f'{b}: テクスチャ {t} あり', tex_exists(t), t)
    check(f'{b}: item model あり', os.path.exists(f'{A}/models/item/{b}.json'))
    for l in lang: check(f'{b}: lang[{l}] block.nexusdefense.{b}', f'block.nexusdefense.{b}' in lang[l])

print('\n[通常アイテム]')
for i in item_ids:
    mp = f'{A}/models/item/{i}.json'
    check(f'{i}: item model あり', os.path.exists(mp))
    if os.path.exists(mp):
        for t in model_textures(f'nexusdefense:item/{i}'): check(f'{i}: テクスチャ {t} あり', tex_exists(t), t)
    for l in lang: check(f'{i}: lang[{l}]', f'item.nexusdefense.{i}' in lang[l])

print('\n[Mob (GeckoLib)]')
for m in mob_ids:
    geo = f'{A}/geo/{m}.geo.json'; an = f'{A}/animations/{m}.animation.json'; tx = f'{A}/textures/entity/{m}.png'
    check(f'{m}: geo あり', os.path.exists(geo)); check(f'{m}: animation あり', os.path.exists(an)); check(f'{m}: texture あり', os.path.exists(tx))
    if os.path.exists(geo) and os.path.exists(tx):
        g = json.load(open(geo))['minecraft:geometry'][0]['description']
        im = Image.open(tx)
        check(f'{m}: geo の texture 寸法 {g["texture_width"]}x{g["texture_height"]} == PNG {im.size}', (g['texture_width'], g['texture_height']) == im.size)
    if os.path.exists(an) and m != 'pit_colossus':
        names = json.load(open(an))['animations']
        for suffix in ('idle', 'walk'):
            check(f'{m}: animation.nexusdefense.{m}.{suffix} 定義あり', f'animation.nexusdefense.{m}.{suffix}' in names)
    for l in lang:
        check(f'{m}: lang[{l}] entity', f'entity.nexusdefense.{m}' in lang[l])
        check(f'{m}: lang[{l}] spawn egg', f'item.nexusdefense.{m}_spawn_egg' in lang[l])
    check(f'{m}: spawn egg model あり', os.path.exists(f'{A}/models/item/{m}_spawn_egg.json'))
check('pit_colossus: glowmask あり', os.path.exists(f'{A}/textures/entity/pit_colossus_glowmask.png'))

print('\n[アニメーションテクスチャ]')
for mc in glob.glob(f'{A}/textures/block/*.png.mcmeta'):
    png = mc[:-7]; im = Image.open(png); fr = json.load(open(mc))['animation']
    check(f'{os.path.basename(png)}: 縦長({im.size}) = 正方フレームの整数倍', im.size[1] % im.size[0] == 0 and fr.get('frametime', 1) > 0)

print('\n[全モデル/blockstate/JSON]')
for f in glob.glob(f'{A}/**/*.json', recursive=True) + glob.glob(f'{ROOT}/src/main/resources/data/**/*.json', recursive=True):
    try: json.load(open(f, encoding='utf-8'))
    except Exception as e: check(f'JSON構文 {f}', False, str(e))
for f in glob.glob(f'{A}/models/**/*.json', recursive=True):
    rel = f.split('models/')[1][:-5]
    if rel.startswith('item/') and rel.endswith('_spawn_egg'): continue
    for t in model_textures('nexusdefense:' + rel): check(f'{rel}: テクスチャ {t}', tex_exists(t), t)
check('assets/minecraft(バニラ上書き)を含まない', not os.path.exists(f'{ROOT}/src/main/resources/assets/minecraft'))
for b in block_ids:
    check(f'{b}: 戦利品表あり', os.path.exists(f'{ROOT}/src/main/resources/data/nexusdefense/loot_tables/blocks/{b}.json'))

print('\n[層の分離]')
for f in glob.glob(f'{J}/core/**/*.java', recursive=True):
    check(f'{os.path.relpath(f, J)}: net.minecraft を import しない', 'net.minecraft' not in open(f, encoding='utf-8').read())

print(f'\n==== 監査: {ok} OK / {bad} NG ====')
sys.exit(1 if bad else 0)
