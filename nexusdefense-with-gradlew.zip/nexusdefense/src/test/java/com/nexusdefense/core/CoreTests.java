package com.nexusdefense.core;

import com.nexusdefense.core.ai.*;
import com.nexusdefense.core.common.*;
import com.nexusdefense.core.decision.*;
import com.nexusdefense.core.nexus.*;
import com.nexusdefense.core.wave.*;

import java.util.*;

/** 依存ライブラリ無しで動く検証ランナー。 java -cp build/core com.nexusdefense.core.CoreTests */
public final class CoreTests {
    static int pass, fail;
    static final List<String> failures = new ArrayList<>();

    static void check(String name, boolean ok) {
        if (ok) { pass++; System.out.println("  PASS  " + name); }
        else { fail++; failures.add(name); System.out.println("  FAIL  " + name); }
    }
    static void near(String name, double expected, double actual) {
        check(name + " (expected " + expected + ", actual " + actual + ")", Math.abs(expected - actual) < 1e-6);
    }

    public static void main(String[] args) {
        run("Nexus状態機械", CoreTests::nexusTests);
        run("Wave予算式", CoreTests::budgetTests);
        run("編成(EncounterComposer)", CoreTests::composerTests);
        run("Phase進行(PhaseRunner)", CoreTests::phaseTests);
        run("行動評価・ヒステリシス", CoreTests::decisionTests);
        run("予約(BlockReservations)", CoreTests::reservationTests);
        run("経路探索 突破シナリオ", CoreTests::navScenarioTests);
        run("A*の最適性(ヒューリスティクスの許容性)", CoreTests::optimalityTests);
        run("計画の実行シミュレーション", CoreTests::executionTests);
        printWaveTable();
        System.out.println("\n==== " + pass + " passed, " + fail + " failed ====");
        if (fail > 0) { failures.forEach(f -> System.out.println("FAILED: " + f)); System.exit(1); }
    }

    static void run(String title, Runnable r) {
        System.out.println("\n[" + title + "]");
        try { r.run(); } catch (Throwable t) { fail++; failures.add(title + " threw " + t); t.printStackTrace(System.out); }
    }

    // ---------------------------------------------------------------- Nexus
    static void nexusTests() {
        NexusStateMachine m = new NexusStateMachine();
        NexusData d = new NexusData(100);
        check("初期状態は INACTIVE", d.state() == NexusState.INACTIVE);
        check("INACTIVE で WaveCleared は拒否", !m.fire(d, new NexusTrigger.WaveCleared(1)).accepted());
        check("T1 Start: INACTIVE→PREPARING", m.fire(d, new NexusTrigger.StartRequested()).to() == NexusState.PREPARING);
        check("PREPARING で Start 再要求は拒否(二重開始防止)", !m.fire(d, new NexusTrigger.StartRequested()).accepted());
        check("T2 CatalystValidated: →ACTIVE", m.fire(d, new NexusTrigger.CatalystValidated()).to() == NexusState.ACTIVE);
        check("ACTIVE でダメージ受理", m.damage(d, 30).outcome() == DamageResult.Outcome.APPLIED);
        near("HPは70", 70, d.health());
        check("負のダメージは拒否", m.damage(d, -5).outcome() == DamageResult.Outcome.REJECTED_INVALID);
        check("NaNダメージは拒否", m.damage(d, Double.NaN).outcome() == DamageResult.Outcome.REJECTED_INVALID);
        check("T4 WaveCleared: →WAVE_TRANSITION", m.fire(d, new NexusTrigger.WaveCleared(1)).to() == NexusState.WAVE_TRANSITION);
        check("WAVE_TRANSITION 中はダメージ拒否", m.damage(d, 10).outcome() == DamageResult.Outcome.REJECTED_STATE);
        check("T6 Pause(WAVE_TRANSITION)→PAUSED", m.fire(d, new NexusTrigger.PauseRequested()).to() == NexusState.PAUSED);
        check("PAUSED 中はダメージ拒否(無敵)", m.damage(d, 10).outcome() == DamageResult.Outcome.REJECTED_STATE);
        check("T7 Resume は元の WAVE_TRANSITION に戻る", m.fire(d, new NexusTrigger.ResumeRequested()).to() == NexusState.WAVE_TRANSITION);
        check("T5 TransitionElapsed: →ACTIVE", m.fire(d, new NexusTrigger.TransitionElapsed()).to() == NexusState.ACTIVE);
        check("Wave が 2 に進む", d.wave() == 2);
        check("maxWaveReached が 1", d.maxWaveReached() == 1);
        DamageResult lethal = m.damage(d, 1000);
        check("致死ダメージで lethal=true", lethal.lethal());
        check("T10 致死ダメージで DEFEATED", d.state() == NexusState.DEFEATED);
        near("HPは0で下限固定", 0, d.health());
        check("DEFEATED→ACTIVE は存在しない", !m.fire(d, new NexusTrigger.CatalystValidated()).accepted());
        check("DEFEATED で Resume は拒否", !m.fire(d, new NexusTrigger.ResumeRequested()).accepted());
        check("T11 Reset: DEFEATED→INACTIVE", m.fire(d, new NexusTrigger.ResetRequested()).to() == NexusState.INACTIVE);
        check("maxWaveReached は Reset 後も保持", d.maxWaveReached() == 1);
        // STOP 経路
        m.fire(d, new NexusTrigger.StartRequested()); m.fire(d, new NexusTrigger.CatalystValidated());
        near("再開始で HP が全回復", 100, d.health());
        check("T8 Stop: ACTIVE→STOPPED", m.fire(d, new NexusTrigger.StopRequested()).to() == NexusState.STOPPED);
        check("T9 CleanupFinished: STOPPED→INACTIVE", m.fire(d, new NexusTrigger.CleanupFinished()).to() == NexusState.INACTIVE);
        check("T3 PREPARING で Rejected→INACTIVE", m.fire(d, new NexusTrigger.StartRequested()).accepted()
            && m.fire(d, new NexusTrigger.CatalystRejected()).to() == NexusState.INACTIVE);
        check("T12 Integrity: 任意→ERROR", m.fire(d, new NexusTrigger.IntegrityViolation("x")).to() == NexusState.ERROR);
        check("ERROR→INACTIVE", m.fire(d, new NexusTrigger.CleanupFinished()).to() == NexusState.INACTIVE);
        NexusData e = new NexusData(10);
        check("canFire は状態を変えない", m.canFire(e, new NexusTrigger.StartRequested()) && e.state() == NexusState.INACTIVE);
    }

    // ---------------------------------------------------------------- Budget
    static void budgetTests() {
        BudgetCalculator c = new BudgetCalculator(BudgetPolicy.defaults());
        double[][] table = {{1, 15.5}, {2, 22}, {5, 47.5}, {10, 110}, {20, 310}, {30, 610}};
        for (double[] row : table)
            near("B(" + (int) row[0] + ") 難度1.0・1人", row[1], c.waveBudget(new BudgetContext((int) row[0], 1, 1.0, 1.0)));
        near("B(10) 4人 = 110×1.45", 159.5, c.waveBudget(new BudgetContext(10, 4, 1.0, 1.0)));
        near("人数は8人で頭打ち", c.waveBudget(new BudgetContext(10, 8, 1.0, 1.0)), c.waveBudget(new BudgetContext(10, 50, 1.0, 1.0)));
        near("難度2.0で2倍", 220, c.waveBudget(new BudgetContext(10, 1, 2.0, 1.0)));
        near("Phase予算 = Wave予算×0.25", 27.5, c.phaseBudget(new BudgetContext(10, 1, 1.0, 1.0), 0, 0));
        near("繰越は Phase予算の50%まで", 27.5 + 13.75, c.phaseBudget(new BudgetContext(10, 1, 1.0, 1.0), 1, 999));
        near("負の繰越は無視", 27.5, c.phaseBudget(new BudgetContext(10, 1, 1.0, 1.0), 1, -5));
    }

    static EncounterComposer composer() { return new EncounterComposer(MobCatalog.prototype(), new ThemeCatalog()); }

    static void composerTests() {
        EncounterComposer ec = composer();
        boolean never = true, deterministic = true;
        for (int w = 1; w <= 40; w++) for (int p = 0; p < 4; p++) {
            double b = new BudgetCalculator(BudgetPolicy.defaults()).phaseBudget(new BudgetContext(w, 2, 1.0, 1.0), p, 0);
            PhaseComposeRequest req = new PhaseComposeRequest(w, p, b, new ThemeCatalog().pick(w, p));
            PhasePlan a = ec.compose(req, new SeededRng(w * 31L + p));
            PhasePlan a2 = ec.compose(req, new SeededRng(w * 31L + p));
            if (a.spent() > b + 1e-6) never = false;
            if (a.tickets().size() != a2.tickets().size()) deterministic = false;
        }
        check("全Wave1〜40・全Phaseで編成コストが予算を超えない", never);
        check("同じ種なら同じ編成(再現性)", deterministic);
        PhasePlan w1 = ec.compose(new PhaseComposeRequest(1, 0, 3.9, PhaseTheme.SWARM), new SeededRng(1));
        check("Wave1 は Zombie のみ(Miner は minWave=2)", w1.tickets().stream().allMatch(t -> t.mobId().equals("zombie")));
        PhasePlan w5 = ec.compose(new PhaseComposeRequest(5, 2, 60, PhaseTheme.SIEGE), new SeededRng(7));
        long eng = w5.tickets().stream().filter(t -> t.role() == Role.ENGINEER).count();
        check("Engineer は全体の20%上限内 (n=" + w5.tickets().size() + ", eng=" + eng + ")",
            eng <= Math.max(1, Math.ceil(0.2 * w5.tickets().size())));
        check("予算が最小コスト未満なら編成0件・全額が繰越", ec.compose(new PhaseComposeRequest(1, 0, 0.5, PhaseTheme.SWARM), new SeededRng(1)).tickets().isEmpty());
    }

    // ---------------------------------------------------------------- Phase
    /** テスト用ゲートウェイ: 要求を溜め、テストが結果を返す。 */
    static final class Gate implements PhaseRunner.SpawnGateway {
        final List<SpawnTicket> requests = new ArrayList<>();
        @Override public void request(SpawnTicket t) { requests.add(t); }
    }

    static PhaseRunner runner(Gate g, double budget, PhaseRunner.Settings s) {
        return new PhaseRunner(new PhaseComposeRequest(3, 0, budget, PhaseTheme.SWARM), composer(), g, new SeededRng(5), s, 0);
    }

    static void phaseTests() {
        Gate g = new Gate();
        PhaseRunner r = runner(g, 6.0, new PhaseRunner.Settings(10, 2, 100, 100, 3));
        check("初期は WAITING", r.state() == PhaseState.WAITING);
        r.tick(5);
        check("gap中は WAITING のまま", r.state() == PhaseState.WAITING);
        r.tick(10);
        check("gap経過で SPAWNING (計画あり)", r.state() == PhaseState.SPAWNING || r.state() == PhaseState.COMBAT);
        int planned = r.counters().planned();
        check("計画数=予算6÷コスト1 = 6体", planned == 6);
        check("全チケット発行済みなら queued=0, pending=6", r.counters().queued() == 0 && r.counters().pendingSpawn() == 6);
        check("不変条件 planned=queued+pending+spawned+failed", r.counters().invariantHolds());
        r.tick(11);
        check("★ AC-004 結果待ち(生存0)でも Phase は完了しない", r.state() != PhaseState.COMPLETED && !r.counters().resolved());
        // 成功4・再試行1・失敗確定1
        for (int i = 0; i < 4; i++) r.onSpawnResult(new SpawnResult.Success(g.requests.get(i).id(), UUID.randomUUID()));
        r.onSpawnResult(new SpawnResult.Retryable(g.requests.get(4).id(), "no space"));
        r.onSpawnResult(new SpawnResult.FailedFinal(g.requests.get(5).id(), "bad biome"));
        check("不変条件が結果処理後も成立", r.counters().invariantHolds());
        check("失敗確定は再抽選され計画数+1", r.counters().planned() == 7 && r.counters().failedFinal() == 1);
        r.tick(12);
        check("再試行と再抽選のチケットが再発行される", g.requests.size() >= 8);
        // 残りを成功させる
        int safety = 0;
        while (r.counters().pendingSpawn() > 0 && safety++ < 20) {
            for (SpawnTicket t : new ArrayList<>(g.requests)) r.onSpawnResult(new SpawnResult.Success(t.id(), UUID.randomUUID()));
            r.tick(13 + safety);
        }
        check("全て解決(resolved)", r.counters().resolved());
        check("生存数=成功数(6)", r.counters().alive() == 6);
        check("生存あり→COMBAT", r.state() == PhaseState.COMBAT);
        for (int i = 0; i < 4; i++) r.onInvaderDied(UUID.randomUUID());
        r.tick(40);
        check("生存が残敵閾値(2)以下→CLEARING", r.state() == PhaseState.CLEARING);
        r.onInvaderDied(UUID.randomUUID());
        r.onInvaderLost(UUID.randomUUID());
        r.tick(41);
        check("生存0かつ全解決→COMPLETED", r.state() == PhaseState.COMPLETED);

        // 子(卵・召喚)は extra として alive に加算される
        Gate g2 = new Gate();
        PhaseRunner r2 = runner(g2, 2.0, new PhaseRunner.Settings(0, 0, 100, 100, 3));
        r2.tick(0);
        for (SpawnTicket t : g2.requests) r2.onSpawnResult(new SpawnResult.Success(t.id(), UUID.randomUUID()));
        r2.registerOffspring(UUID.randomUUID(), UUID.randomUUID());
        check("追加Mob(extra)が生存数に加算", r2.counters().alive() == 3);
        r2.reconcile(1);
        check("reconcile で実生存数に補正(差分は lost)", r2.counters().alive() == 1 && r2.counters().lost() == 2);

        // 同時出現上限: 上限3なら一度に3体まで
        Gate g3 = new Gate();
        PhaseRunner r3 = runner(g3, 10.0, new PhaseRunner.Settings(0, 0, 100, 3, 3));
        r3.tick(0);
        check("同時出現上限3で発行は3体まで", g3.requests.size() == 3 && r3.counters().queued() == 7);
        check("上限待ちの間は SPAWNING のまま", r3.state() == PhaseState.SPAWNING);

        // 計画0件(予算不足)は即 COMPLETED
        Gate g4 = new Gate();
        PhaseRunner r4 = runner(g4, 0.5, new PhaseRunner.Settings(0, 0, 100, 100, 3));
        r4.tick(0);
        check("予算不足なら 0件で COMPLETED(予算は繰越)", r4.state() == PhaseState.COMPLETED && Math.abs(r4.unspentBudget() - 0.5) < 1e-9);

        // WaveController: 4 Phase を通して waveCleared になる
        Gate g5 = new Gate();
        List<String> log = new ArrayList<>();
        WaveController wc = new WaveController(BudgetPolicy.defaults(), composer(), new ThemeCatalog(), g5, new SeededRng(9),
            new PhaseRunner.Settings(2, 0, 100, 100, 3), (w, p, th, b) -> log.add(w + ":" + p + ":" + th));
        wc.startWave(1, 1, 1.0, 0);
        long t = 0; int guard = 0;
        while (!wc.waveCleared() && guard++ < 2000) {
            t++;
            wc.tick(t);
            for (SpawnTicket tk : new ArrayList<>(g5.requests)) {
                UUID inv = UUID.randomUUID();
                wc.onSpawnResult(new SpawnResult.Success(tk.id(), inv));
                wc.onInvaderDied(inv);
            }
            g5.requests.clear();
        }
        check("Wave1 は 4 Phase を経て waveCleared", wc.waveCleared());
        check("Phase開始通知が 4 回 (SWARM,MELEE,SIEGE,MIXED)", log.size() == 4 && log.get(0).endsWith("SWARM") && log.get(3).endsWith("MIXED"));
    }

    // ---------------------------------------------------------------- Decision
    static ActionCandidate cand(ActionKind k, double total) {
        return new ActionCandidate(k, new ScoreBreakdown(total, 0, 0, 0, 0, 0, 0), "t");
    }

    static void decisionTests() {
        double dig = ActionScorer.score(ActionKind.DIG_BLOCKER, Role.ENGINEER, 100, 40, 0, 0, 4, 0).total();
        double build = ActionScorer.score(ActionKind.BUILD_CROSSING, Role.ENGINEER, 100, 20, 0, 0, 7.5, 0).total();
        near("設計書の数値例: Engineer DIG = 65", 65.0, dig);
        near("設計書の数値例: Engineer BUILD = 84.5", 84.5, build);
        HysteresisSelector sel = HysteresisSelector.defaults();
        ActiveAction cur = new ActiveAction(ActionKind.BUILD_CROSSING, 0, build);
        check("DIG(70)が出ても 84.5×1.25 に届かず維持", !sel.select(cur, List.of(cand(ActionKind.DIG_BLOCKER, 70)), 100).switched());
        check("継続20tick未満は大幅優位でも維持", !sel.select(cur, List.of(cand(ActionKind.ATTACK_NEXUS, 200)), 10).switched());
        check("20tick経過後に十分な優位があれば切替", sel.select(cur, List.of(cand(ActionKind.ATTACK_NEXUS, 120)), 25).switched());
        ActiveAction low = new ActiveAction(ActionKind.FOLLOW_PLAN, 0, 2);
        check("現在スコアが低いときも +5 の絶対差が必要", !sel.select(low, List.of(cand(ActionKind.REPOSITION, 4)), 100).switched());
        ActiveAction bad = new ActiveAction(ActionKind.FOLLOW_PLAN, 0, 50);
        bad.invalidate();
        check("前提崩れ(invalidated)なら即切替", sel.select(bad, List.of(cand(ActionKind.DIG_BLOCKER, 10)), 1).switched());
        // 振動テスト: スコアが±に揺れる 200tick で切替回数が少ない
        ActiveAction a = new ActiveAction(ActionKind.DIG_BLOCKER, 0, 65);
        int switches = 0;
        Random rnd = new Random(3);
        for (long tick = 1; tick <= 200; tick++) {
            double sDig = 65 + rnd.nextGaussian() * 8, sBuild = 70 + rnd.nextGaussian() * 8;
            Selection s = sel.select(a, List.of(cand(ActionKind.DIG_BLOCKER, sDig), cand(ActionKind.BUILD_CROSSING, sBuild)), tick);
            if (s.switched()) { switches++; a = new ActiveAction(s.chosen().kind(), tick, s.chosen().score().total()); }
            else a.updateScore(a.kind() == ActionKind.DIG_BLOCKER ? sDig : sBuild);
        }
        check("ノイズ(σ=8)の200tickで切替が10回以内 (実測 " + switches + ")", switches <= 10);
        // ヒステリシスなしの素朴実装との比較
        int naive = 0; ActionKind last = ActionKind.DIG_BLOCKER; rnd = new Random(3);
        for (int tick = 1; tick <= 200; tick++) {
            double sDig = 65 + rnd.nextGaussian() * 8, sBuild = 70 + rnd.nextGaussian() * 8;
            ActionKind k = sBuild > sDig ? ActionKind.BUILD_CROSSING : ActionKind.DIG_BLOCKER;
            if (k != last) { naive++; last = k; }
        }
        check("素朴な最大値選択は振動する (切替 " + naive + " 回 > ヒステリシス)", naive > switches * 3);
    }

    static void reservationTests() {
        BlockReservations r = new BlockReservations();
        UUID a = UUID.randomUUID(), b = UUID.randomUUID();
        CellPos c = new CellPos(1, 1, 1);
        check("最初の予約は成功", r.tryReserve(a, Set.of(c), 0, 100).isPresent());
        check("他者の重複予約は拒否", r.tryReserve(b, Set.of(c), 10, 100).isEmpty());
        check("同一所有者の再予約は可", r.tryReserve(a, Set.of(c), 10, 100).isPresent());
        check("他者から見て予約中", r.isReservedByOther(b, c, 50));
        check("TTL経過後は自動解放され他者が予約可", r.tryReserve(b, Set.of(c), 200, 100).isPresent());
        r.releaseAll(b);
        check("所有者の全解放で空", r.size() <= 1);
    }

    // ---------------------------------------------------------------- Navigation scenarios
    static final BlockInfo HARD = BlockInfo.solid(6.0);   // 石より硬い(Zombie/Engineer は壊せない)

    /** 幅3の通路。壁は岩盤(高さ8)で、ドロップ上限(4)を超えるので壁越えの迂回は不可。 */
    static InMemoryWorld corridor() {
        InMemoryWorld w = new InMemoryWorld(-8, 12).bounds(0, 40, 0, 40);
        w.fill(0, -8, 0, 40, 0, 40, BlockInfo.STONE);
        w.fill(0, 1, 18, 40, 8, 18, BlockInfo.BEDROCK);
        w.fill(0, 1, 22, 40, 8, 22, BlockInfo.BEDROCK);
        w.set(38, 1, 20, BlockInfo.BEDROCK);                     // Nexus
        return w;
    }
    static final CellPos START = new CellPos(2, 1, 20), NEXUS = new CellPos(38, 1, 20);
    static final AStarPlanner PLANNER = new AStarPlanner();

    static Map<EdgeType, Integer> count(PathPlan p) {
        Map<EdgeType, Integer> m = new EnumMap<>(EdgeType.class);
        for (PathStep s : p.steps()) m.merge(s.edge(), 1, Integer::sum);
        return m;
    }
    static PathPlan plan(WorldView w, MobProfile p, CellPos s, CellPos g) { return PLANNER.plan(w, p, s, g, 1, 20000, 80); }

    static void navScenarioTests() {
        // 平地
        PathPlan flat = plan(corridor(), MobProfiles.ZOMBIE, START, NEXUS);
        check("開けた通路: 完全な経路・WALKのみ", !flat.partial() && count(flat).keySet().equals(Set.of(EdgeType.WALK)));
        near("開けた通路のコスト = 35歩", 35, flat.totalCost());

        // 石の栓(厚み2)
        InMemoryWorld stone = corridor(); stone.fill(20, 1, 19, 21, 4, 21, BlockInfo.STONE);
        PathPlan zs = plan(stone, MobProfiles.ZOMBIE, START, NEXUS), ms = plan(stone, MobProfiles.MINER, START, NEXUS);
        PathPlan es = plan(stone, MobProfiles.ENGINEER, START, NEXUS);
        check("石の栓: Zombie は DIG で突破(完全経路)", !zs.partial() && count(zs).getOrDefault(EdgeType.DIG, 0) > 0);
        check("石の栓: Miner の方が Zombie より安い (" + String.format("%.1f", ms.totalCost()) + " < " + String.format("%.1f", zs.totalCost()) + ")", ms.totalCost() < zs.totalCost());
        check("石の栓(厚み2): Engineer は 掘る/はしご が同コストで引き分け(" + String.format("%.1f", es.totalCost()) + "=" + String.format("%.1f", ms.totalCost()) + ")",
            !es.partial() && Math.abs(es.totalCost() - ms.totalCost()) < 1e-6);
        InMemoryWorld wall3 = corridor(); wall3.fill(20, 1, 19, 20, 3, 21, BlockInfo.STONE);   // AC-005: 3×3 の石壁
        PathPlan e3 = plan(wall3, MobProfiles.ENGINEER, START, NEXUS);
        check("★AC-005 3×3石壁: Engineer は DIG を選び LADDER は使わない " + count(e3), !e3.partial() && count(e3).getOrDefault(EdgeType.DIG, 0) > 0 && !count(e3).containsKey(EdgeType.LADDER));
        check("3×3石壁: Zombie も DIG で突破", !plan(wall3, MobProfiles.ZOMBIE, START, NEXUS).partial());

        // 黒曜石の栓: 掘れない → Engineer だけ はしごで栓の上を越える
        InMemoryWorld obs = corridor(); obs.fill(20, 1, 19, 21, 4, 21, BlockInfo.OBSIDIAN);
        PathPlan zo = plan(obs, MobProfiles.ZOMBIE, START, NEXUS), mo = plan(obs, MobProfiles.MINER, START, NEXUS);
        PathPlan eo = plan(obs, MobProfiles.ENGINEER, START, NEXUS);
        check("黒曜石の栓: Zombie は突破不能(partial)", zo.partial());
        check("黒曜石の栓: Miner も突破不能(partial)", mo.partial());
        check("黒曜石の栓: Engineer は LADDER(3段)+JUMP で越える(DIGしない) " + count(eo), !eo.partial() && count(eo).getOrDefault(EdgeType.LADDER, 0) >= 3 && !count(eo).containsKey(EdgeType.DIG));

        // 堀(幅3・深さ6)
        InMemoryWorld moat = corridor(); moat.fill(20, -5, 19, 22, 0, 21, BlockInfo.AIR);
        PathPlan zm = plan(moat, MobProfiles.ZOMBIE, START, NEXUS), em = plan(moat, MobProfiles.ENGINEER, START, NEXUS);
        check("堀: Zombie は渡れない(partial)", zm.partial());
        check("堀: Engineer は BRIDGE 3ブロックで渡る (AC-006)", !em.partial() && count(em).getOrDefault(EdgeType.BRIDGE, 0) == 3);
        near("堀: 橋のコスト 3×2.5 を含む総コスト = 35−3+7.5", 39.5, em.totalCost());
        // 浅い堀(深さ2): Zombie は落ちた後、壁を掘って脱出する
        InMemoryWorld shallow = corridor(); shallow.fill(20, -1, 19, 22, 0, 21, BlockInfo.AIR);
        PathPlan zsh = plan(shallow, MobProfiles.ZOMBIE, START, NEXUS);
        check("浅い堀(深さ2): Zombie は DROP で落ち、DIG で脱出する " + count(zsh), !zsh.partial()
            && count(zsh).containsKey(EdgeType.DROP) && count(zsh).containsKey(EdgeType.DIG));

        // 崖(高さ6・壁面あり)
        InMemoryWorld cliff = new InMemoryWorld(-8, 12).bounds(0, 40, 0, 40);
        cliff.fill(0, -8, 0, 40, 0, 40, BlockInfo.STONE);
        cliff.fill(30, 1, 0, 40, 6, 40, HARD);
        cliff.set(35, 7, 20, BlockInfo.BEDROCK);
        CellPos top = new CellPos(35, 7, 20);
        PathPlan zc = plan(cliff, MobProfiles.ZOMBIE, START, top), ec = plan(cliff, MobProfiles.ENGINEER, START, top);
        check("崖: Zombie は登れない(partial)", zc.partial());
        check("★AC-007 崖(高さ6): Engineer は LADDER 5段+JUMP で登る " + count(ec), !ec.partial() && count(ec).getOrDefault(EdgeType.LADDER, 0) == 5 && count(ec).getOrDefault(EdgeType.JUMP, 0) == 1);

        // 空中の足場(壁面なし)→ 塔
        InMemoryWorld island = new InMemoryWorld(-8, 12).bounds(0, 40, 0, 40);
        island.fill(0, -8, 0, 40, 0, 40, BlockInfo.STONE);
        island.fill(30, 6, 15, 40, 6, 25, HARD);
        island.set(35, 7, 20, BlockInfo.BEDROCK);
        PathPlan ei = plan(island, MobProfiles.ENGINEER, START, top);
        check("空中足場: Engineer は TOWER を3回以上使う " + count(ei), !ei.partial() && count(ei).getOrDefault(EdgeType.TOWER, 0) >= 3 && !count(ei).containsKey(EdgeType.DIG));
        check("空中足場: Zombie は到達不能", plan(island, MobProfiles.ZOMBIE, START, top).partial());

        // 溶岩(ハザード)の上は通れない
        InMemoryWorld lava = corridor(); lava.fill(20, 0, 19, 22, 0, 21, BlockInfo.HAZARD);
        check("溶岩の床: Zombie は通れない(partial)", plan(lava, MobProfiles.ZOMBIE, START, NEXUS).partial());

        // 保護ブロック(岩盤)の壁は誰も壊せない
        InMemoryWorld plug = corridor(); plug.fill(20, 1, 19, 20, 8, 21, BlockInfo.BEDROCK);
        check("岩盤の栓(高さ8): Engineer も突破不能", plan(plug, MobProfiles.ENGINEER, START, NEXUS).partial());

        // 再検証: 計画後にブロックが置かれたら実行時に検出できる
        PathStep first = flat.steps().get(0);
        InMemoryWorld w2 = corridor();
        check("revalidate: 通常は同じ到達セルへのエッジを返す", new EdgeGenerator().revalidate(w2, MobProfiles.ZOMBIE, first).isPresent());
        w2.fill(3, 1, 19, 3, 8, 21, BlockInfo.BEDROCK);
        check("revalidate: 進路が岩盤で塞がれたら empty (=再計画のトリガー)", new EdgeGenerator().revalidate(w2, MobProfiles.ZOMBIE, first).isEmpty());
    }

    // ---------------------------------------------------------------- Optimality
    static void optimalityTests() {
        Random rnd = new Random(42);
        int worlds = 60, compared = 0, mismatches = 0, expandedH = 0, expandedD = 0;
        MobProfile[] profiles = {MobProfiles.ZOMBIE, MobProfiles.MINER, MobProfiles.ENGINEER};
        for (int i = 0; i < worlds; i++) {
            InMemoryWorld w = new InMemoryWorld(-3, 7).bounds(0, 13, 0, 13);
            w.fill(0, -3, 0, 13, 0, 13, BlockInfo.STONE);
            for (int x = 1; x <= 12; x++) for (int z = 1; z <= 12; z++) for (int y = 1; y <= 3; y++) {
                double r = rnd.nextDouble();
                if (r < 0.14) w.set(x, y, z, BlockInfo.STONE);
                else if (r < 0.20) w.set(x, y, z, BlockInfo.DIRT);
                else if (r < 0.26) w.set(x, y, z, HARD);
                else if (r < 0.30) w.set(x, y, z, BlockInfo.BEDROCK);
            }
            for (int y = 1; y <= 3; y++) { w.set(1, y, 6, BlockInfo.AIR); w.set(12, y, 6, BlockInfo.AIR); }
            w.set(12, 1, 6, BlockInfo.BEDROCK);
            CellPos s = new CellPos(1, 1, 6), g = new CellPos(12, 1, 6);
            MobProfile p = profiles[i % 3];
            PathPlan a = PLANNER.plan(w, p, s, g, 1, 200000, 30, true);
            PathPlan d = PLANNER.plan(w, p, s, g, 1, 200000, 30, false);
            if (a.partial() != d.partial()) { mismatches++; continue; }
            if (!a.partial()) {
                compared++;
                if (Math.abs(a.totalCost() - d.totalCost()) > 1e-6) mismatches++;
                expandedH += a.expanded(); expandedD += d.expanded();
            }
        }
        check("A*(ヒューリスティクスあり)と全探索(h=0)で最適コストが一致: " + compared + "件中 不一致" + mismatches, compared >= 20 && mismatches == 0);
        check("ヒューリスティクスで展開ノードが減る (" + expandedH + " < " + expandedD + ")", expandedH < expandedD);
    }

    // ---------------------------------------------------------------- Execution
    /** 計画を世界モデル上で実際に実行し(破壊・設置を反映)、Nexus に届くかを検証する。 */
    static int execute(InMemoryWorld w, MobProfile p, CellPos start, CellPos goal, Map<EdgeType, Integer> used) {
        EdgeGenerator gen = new EdgeGenerator();
        CellPos pos = start;
        int replans = 0;
        for (int round = 0; round < 10 && goal.chebyshev(pos) > 1; round++) {
            PathPlan plan = PLANNER.plan(w, p, pos, goal, 1, 20000, 80);
            if (plan.steps().isEmpty()) return -1;
            boolean aborted = false;
            for (PathStep s : plan.steps()) {
                Optional<PathStep> f = gen.revalidate(w, p, s);
                if (f.isEmpty()) { aborted = true; replans++; break; }
                PathStep e = f.get();
                for (CellPos b : e.breaks()) w.set(b, BlockInfo.AIR);
                if (e.edge() == EdgeType.BRIDGE || e.edge() == EdgeType.TOWER) w.set(e.place(), BlockInfo.STONE);
                if (e.edge() == EdgeType.LADDER) w.set(e.place(), BlockInfo.LADDER);
                used.merge(e.edge(), 1, Integer::sum);
                pos = e.to();
            }
            if (plan.partial() && !aborted && goal.chebyshev(pos) > 1) return -1;
        }
        return goal.chebyshev(pos) <= 1 ? replans : -1;
    }

    static void executionTests() {
        Map<EdgeType, Integer> u = new EnumMap<>(EdgeType.class);
        InMemoryWorld moat = corridor(); moat.fill(20, -5, 19, 22, 0, 21, BlockInfo.AIR);
        check("堀: Engineer が橋を架けて実際に Nexus 近傍へ到達", execute(moat, MobProfiles.ENGINEER, START, NEXUS, u) >= 0);
        check("堀: 実行後、橋ブロックが世界に残る(3個)", moat.block(new CellPos(20, 0, 20)).standable() && moat.block(new CellPos(21, 0, 20)).standable() && moat.block(new CellPos(22, 0, 20)).standable());

        u = new EnumMap<>(EdgeType.class);
        InMemoryWorld obs = corridor(); obs.fill(20, 1, 19, 21, 4, 21, BlockInfo.OBSIDIAN);
        check("黒曜石の栓: Engineer がはしごで越えて到達", execute(obs, MobProfiles.ENGINEER, START, NEXUS, u) >= 0);
        check("  使ったエッジに LADDER を含む " + u, u.getOrDefault(EdgeType.LADDER, 0) >= 3);

        u = new EnumMap<>(EdgeType.class);
        InMemoryWorld stone = corridor(); stone.fill(20, 1, 19, 21, 4, 21, BlockInfo.STONE);
        check("石の栓: Zombie が掘って到達", execute(stone, MobProfiles.ZOMBIE, START, NEXUS, u) >= 0);
        check("  栓の通路が空いた(掘削が世界に反映)", stone.block(new CellPos(20, 1, 20)).passable() && stone.block(new CellPos(20, 2, 20)).passable());

        u = new EnumMap<>(EdgeType.class);
        InMemoryWorld island = new InMemoryWorld(-8, 12).bounds(0, 40, 0, 40);
        island.fill(0, -8, 0, 40, 0, 40, BlockInfo.STONE);
        island.fill(30, 6, 15, 40, 6, 25, HARD);
        island.set(35, 7, 20, BlockInfo.BEDROCK);
        check("空中足場: Engineer が塔を積んで到達", execute(island, MobProfiles.ENGINEER, START, new CellPos(35, 7, 20), u) >= 0);
        check("  使ったエッジに TOWER を含む " + u, u.getOrDefault(EdgeType.TOWER, 0) >= 3);
    }

    // ---------------------------------------------------------------- Wave table
    static void printWaveTable() {
        System.out.println("\n[WaveSimulator: 予算と編成 (難度1.0・1人)]");
        System.out.println("Wave  予算    体数  消費    内訳");
        List<WaveSimulator.Row> rows = WaveSimulator.run(BudgetPolicy.defaults(), composer(), new ThemeCatalog(), 1, 1, 1, 1);
        for (int w : new int[]{1, 2, 3, 5, 10, 20, 30}) {
            WaveSimulator.Row r = WaveSimulator.run(BudgetPolicy.defaults(), composer(), new ThemeCatalog(), w, w, 1, 1).get(0);
            System.out.printf("%-5d %-7.1f %-5d %-7.1f %s%n", r.wave(), r.budget(), r.mobs(), r.spent(), r.byMob());
        }
    }
}
