package com.nexusdefense.game.service;

import com.nexusdefense.game.NdConfig;

/** サーバー全体で 1tick に実行する経路探索の数を制限する（設計書 AiBudget）。 */
public final class AiBudgetGate {
    private static long tick = Long.MIN_VALUE;
    private static int used;
    public static boolean tryAcquire(long gameTime) {
        if (gameTime != tick) { tick = gameTime; used = 0; }
        if (used >= NdConfig.MAX_PATHFINDS_PER_TICK.get()) return false;
        used++;
        return true;
    }
    private AiBudgetGate() {}
}
