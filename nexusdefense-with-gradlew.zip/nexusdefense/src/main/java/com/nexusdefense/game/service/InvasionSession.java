package com.nexusdefense.game.service;

import com.nexusdefense.core.common.SeededRng;
import com.nexusdefense.core.wave.*;
import com.nexusdefense.game.NdConfig;
import com.nexusdefense.game.blockentity.NexusBlockEntity;
import com.nexusdefense.game.entity.InvaderEntity;
import com.nexusdefense.game.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.*;

/** ACTIVE な Nexus 1つにつき1つ。core の WaveController を Minecraft 世界に接続するアダプター。 */
public final class InvasionSession implements PhaseRunner.SpawnGateway {
    private final ServerLevel level;
    private final NexusBlockEntity nexus;
    private final BlockPos pos;
    private final WaveController wc;
    private final Set<UUID> alive = new HashSet<>();
    private final SeededRng rng = new SeededRng(System.nanoTime());
    private int currentWave = 1;

    public InvasionSession(ServerLevel level, NexusBlockEntity nexus) {
        this.level = level; this.nexus = nexus; this.pos = nexus.getBlockPos();
        PhaseRunner.Settings st = new PhaseRunner.Settings(NdConfig.PHASE_GAP_SECONDS.get() * 20, 5,
            NdConfig.SPAWNS_PER_TICK.get(), NdConfig.CONCURRENT_CAP.get(), 3);
        this.wc = new WaveController(BudgetPolicy.defaults(), new EncounterComposer(MobCatalog.prototype(), new ThemeCatalog()),
            new ThemeCatalog(), this, rng, st, this::onPhaseStarted);
    }

    private void onPhaseStarted(int wave, int phaseIndex, PhaseTheme theme, double budget) {
        nexus.broadcast(level, Component.translatable("msg.nexusdefense.phase", wave, phaseIndex + 1, theme.name(), String.format("%.1f", budget)), false);
    }

    public void startWave(int wave, long now) {
        currentWave = wave;
        int players = Math.max(1, level.getEntitiesOfClass(Player.class, new AABB(pos).inflate(64)).size());
        wc.startWave(wave, players, NdConfig.DIFFICULTY.get(), now);
        nexus.broadcast(level, Component.translatable("msg.nexusdefense.wave_start", wave), false);
    }

    public void tick(long now) { wc.tick(now); }
    public boolean waveCleared() { return wc.waveCleared(); }
    public int phaseNumber() { return wc.phaseIndex() + 1; }
    public int aliveCount() { return alive.size(); }
    public boolean tracks(UUID id) { return alive.contains(id); }

    @Override public void request(SpawnTicket t) {
        var type = ModEntities.TYPES.get(t.mobId());
        if (type == null) { wc.onSpawnResult(new SpawnResult.FailedFinal(t.id(), "unknown mob " + t.mobId())); return; }
        for (int i = 0; i < 20; i++) {
            double ang = rng.nextDouble() * Math.PI * 2;
            int min = NdConfig.SPAWN_MIN.get(), max = Math.max(min + 1, NdConfig.SPAWN_MAX.get());
            double dist = min + rng.nextDouble() * (max - min);
            int x = pos.getX() + (int) Math.round(Math.cos(ang) * dist);
            int z = pos.getZ() + (int) Math.round(Math.sin(ang) * dist);
            if (!level.hasChunkAt(new BlockPos(x, pos.getY(), z))) continue;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            if (Math.abs(y - pos.getY()) > 24) continue;
            InvaderEntity e = type.get().create(level);
            if (e == null) continue;
            e.moveTo(x + 0.5, y, z + 0.5, rng.nextInt(360), 0);
            if (!level.noCollision(e)) { continue; }
            e.bindToNexus(pos, currentWave);
            level.addFreshEntity(e);
            alive.add(e.getUUID());
            wc.onSpawnResult(new SpawnResult.Success(t.id(), e.getUUID()));
            return;
        }
        wc.onSpawnResult(new SpawnResult.Retryable(t.id(), "no valid position"));
    }

    public void onInvaderDied(UUID id) { if (alive.remove(id)) { wc.onInvaderDied(id); nexus.addKill(); } }
    public void onInvaderLost(UUID id) { if (alive.remove(id)) wc.onInvaderLost(id); }

    public void discardAll() {
        List<UUID> ids = new ArrayList<>(alive);
        alive.clear();
        for (UUID id : ids) { Entity e = level.getEntity(id); if (e != null) e.discard(); }
    }
}
