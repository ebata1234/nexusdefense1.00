package com.nexusdefense.game.blockentity;

import com.nexusdefense.core.decision.BlockReservations;
import com.nexusdefense.core.nexus.*;
import com.nexusdefense.game.NdConfig;
import com.nexusdefense.game.registry.ModBlockEntities;
import com.nexusdefense.game.service.InvasionSession;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * Nexus Core の BlockEntity。core の NexusData / NexusStateMachine を保持し、tick で Wave を進める。
 * 【試作の簡略化】状態の正本は本来 SavedData だが、試作では BlockEntity の NBT に保存する。
 */
public class NexusBlockEntity extends BlockEntity {
    private final NexusStateMachine machine = new NexusStateMachine();
    private NexusData data = new NexusData(500);
    private InvasionSession session;
    private long transitionEnd, defeatedAt;
    private final Set<Long> built = new HashSet<>();
    private final BlockReservations reservations = new BlockReservations();

    public NexusBlockEntity(BlockPos pos, BlockState st) { super(ModBlockEntities.NEXUS_CORE.get(), pos, st); }

    public NexusData data() { return data; }
    public BlockReservations reservations() { return reservations; }
    public boolean isRunning() { NexusState s = data.state(); return s == NexusState.ACTIVE || s == NexusState.WAVE_TRANSITION || s == NexusState.PAUSED; }
    public boolean tracks(UUID id) { return session != null && session.tracks(id); }
    public void addKill() { data.addKill(); }
    public void sessionDied(UUID id) { if (session != null) session.onInvaderDied(id); }
    public void sessionLost(UUID id) { if (session != null) session.onInvaderLost(id); }
    public void markBuilt(BlockPos p) { built.add(p.asLong()); setChanged(); }

    // ------------------------------------------------------------ 操作（サーバー側で検証）
    public boolean tryStart(ServerPlayer p) {
        if (data.state() != NexusState.INACTIVE) { p.displayClientMessage(Component.translatable("msg.nexusdefense.already_running"), true); return false; }
        int maxWave = data.maxWaveReached();
        data = new NexusData(NdConfig.NEXUS_HEALTH.get());
        data.restore(NexusState.INACTIVE, NexusState.ACTIVE, data.maxHealth(), 1, maxWave, 0);
        machine.fire(data, new NexusTrigger.StartRequested());
        setChanged();
        p.displayClientMessage(Component.translatable("msg.nexusdefense.started"), false);
        return true;
    }

    public void stop(ServerPlayer p) {
        if (machine.fire(data, new NexusTrigger.StopRequested()).accepted()) {
            p.displayClientMessage(Component.translatable("msg.nexusdefense.stopped"), false);
            setChanged();
        } else p.displayClientMessage(Component.translatable("msg.nexusdefense.not_running"), true);
    }

    public void sendStatus(ServerPlayer p) {
        p.displayClientMessage(statusComponent(), false);
    }

    private Component statusComponent() {
        return Component.translatable("msg.nexusdefense.status", data.state().name(), data.wave(),
            session == null ? 0 : session.phaseNumber(), (int) data.health() + "/" + (int) data.maxHealth(),
            session == null ? 0 : session.aliveCount(), data.maxWaveReached());
    }

    /** 侵略者からのダメージ。ACTIVE のときだけ受理される。 */
    public void damageFromInvader(double amount) {
        DamageResult r = machine.damage(data, amount);
        if (r.outcome() == DamageResult.Outcome.APPLIED) setChanged();
        if (r.lethal() && level instanceof ServerLevel sl) {
            defeatedAt = sl.getGameTime();
            if (session != null) session.discardAll();
            broadcast(sl, Component.translatable("msg.nexusdefense.defeated", data.wave(), data.maxWaveReached()), false);
        }
    }

    // ------------------------------------------------------------ tick
    public static void serverTick(Level level, BlockPos pos, BlockState st, NexusBlockEntity be) {
        if (level instanceof ServerLevel sl) be.tick(sl);
    }

    private void tick(ServerLevel level) {
        long now = level.getGameTime();
        NexusState s = data.state();
        switch (s) {
            case PREPARING -> { machine.fire(data, new NexusTrigger.CatalystValidated()); beginSession(level, now); setChanged(); }
            case ACTIVE -> {
                if (session == null) beginSession(level, now);
                session.tick(now);
                if (session.waveCleared()) {
                    machine.fire(data, new NexusTrigger.WaveCleared(data.wave()));
                    transitionEnd = now + NdConfig.WAVE_GAP_SECONDS.get() * 20L;
                    broadcast(level, Component.translatable("msg.nexusdefense.wave_cleared", data.wave()), false);
                    setChanged();
                }
            }
            case WAVE_TRANSITION -> {
                if (now >= transitionEnd) {
                    machine.fire(data, new NexusTrigger.TransitionElapsed());
                    if (session == null) beginSession(level, now); else session.startWave(data.wave(), now);
                    setChanged();
                }
            }
            case DEFEATED -> {
                if (now - defeatedAt > 100) { finishCleanup(level); machine.fire(data, new NexusTrigger.ResetRequested()); setChanged(); }
            }
            case STOPPED -> { finishCleanup(level); machine.fire(data, new NexusTrigger.CleanupFinished()); setChanged(); }
            default -> {}
        }
        if (now % 20 == 0 && (s == NexusState.ACTIVE || s == NexusState.WAVE_TRANSITION)) broadcast(level, statusComponent(), true);
    }

    private void beginSession(ServerLevel level, long now) {
        session = new InvasionSession(level, this);
        session.startWave(data.wave(), now);
    }

    private void finishCleanup(ServerLevel level) {
        if (session != null) { session.discardAll(); session = null; }
        if (NdConfig.CLEANUP_BUILT_BLOCKS.get()) {
            for (Iterator<Long> it = built.iterator(); it.hasNext(); ) {
                BlockPos p = BlockPos.of(it.next());
                if (!level.isLoaded(p)) continue;                       // 未ロードは後で
                var bs = level.getBlockState(p);
                if (bs.is(Blocks.COBBLESTONE) || bs.is(Blocks.LADDER)) level.removeBlock(p, false);
                it.remove();
            }
        }
    }

    public void broadcast(ServerLevel level, Component msg, boolean actionBar) {
        Vec3 c = Vec3.atCenterOf(worldPosition);
        for (ServerPlayer p : level.players()) if (p.position().distanceToSqr(c) < 80 * 80) p.displayClientMessage(msg, actionBar);
    }

    // ------------------------------------------------------------ 保存
    @Override protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putString("State", data.state().name());
        tag.putString("ResumeTo", data.resumeTo().name());
        tag.putDouble("Health", data.health());
        tag.putDouble("MaxHealth", data.maxHealth());
        tag.putInt("Wave", data.wave());
        tag.putInt("MaxWave", data.maxWaveReached());
        tag.putInt("Kills", data.totalKills());
        tag.putLongArray("Built", built.stream().mapToLong(Long::longValue).toArray());
    }

    @Override public void load(CompoundTag tag) {
        super.load(tag);
        if (!tag.contains("State")) return;
        double max = tag.contains("MaxHealth") ? tag.getDouble("MaxHealth") : 500;
        data = new NexusData(max);
        NexusState st = NexusState.valueOf(tag.getString("State"));
        // 再読込時は進行中の Phase が失われるので、進行中だった状態は ACTIVE から Wave を再開する
        if (st == NexusState.PREPARING || st == NexusState.WAVE_TRANSITION) st = NexusState.ACTIVE;
        data.restore(st, NexusState.valueOf(tag.getString("ResumeTo")), tag.getDouble("Health"),
            tag.getInt("Wave"), tag.getInt("MaxWave"), tag.getInt("Kills"));
        built.clear();
        for (long l : tag.getLongArray("Built")) built.add(l);
    }
}
