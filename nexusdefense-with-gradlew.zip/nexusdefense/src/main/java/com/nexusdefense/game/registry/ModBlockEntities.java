package com.nexusdefense.game.registry;

import com.nexusdefense.game.NexusDefenseMod;
import com.nexusdefense.game.blockentity.NexusBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.*;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
        DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, NexusDefenseMod.MOD_ID);

    public static final RegistryObject<BlockEntityType<NexusBlockEntity>> NEXUS_CORE =
        BLOCK_ENTITIES.register("nexus_core",
            () -> BlockEntityType.Builder.of(NexusBlockEntity::new, ModBlocks.NEXUS_CORE.get()).build(null));
    private ModBlockEntities() {}
}
