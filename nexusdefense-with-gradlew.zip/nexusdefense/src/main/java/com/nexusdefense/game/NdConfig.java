package com.nexusdefense.game;

import net.minecraftforge.common.ForgeConfigSpec;

public final class NdConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue NEXUS_HEALTH, DIFFICULTY;
    public static final ForgeConfigSpec.IntValue SPAWN_MIN, SPAWN_MAX, CONCURRENT_CAP, PHASE_GAP_SECONDS,
        WAVE_GAP_SECONDS, MAX_PATH_NODES, MAX_PATHFINDS_PER_TICK, SPAWNS_PER_TICK;
    public static final ForgeConfigSpec.BooleanValue CLEANUP_BUILT_BLOCKS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("nexus");
        NEXUS_HEALTH = b.defineInRange("max_health", 500.0, 1.0, 100000.0);
        b.pop().push("wave");
        DIFFICULTY = b.defineInRange("difficulty", 1.0, 0.1, 10.0);
        SPAWN_MIN = b.defineInRange("spawn_min_distance", 20, 8, 128);
        SPAWN_MAX = b.defineInRange("spawn_max_distance", 40, 12, 192);
        CONCURRENT_CAP = b.defineInRange("concurrent_cap", 30, 1, 200);
        SPAWNS_PER_TICK = b.defineInRange("spawns_per_tick", 2, 1, 20);
        PHASE_GAP_SECONDS = b.defineInRange("phase_gap_seconds", 10, 0, 300);
        WAVE_GAP_SECONDS = b.defineInRange("wave_gap_seconds", 30, 0, 600);
        b.pop().push("ai");
        MAX_PATH_NODES = b.defineInRange("max_path_nodes", 1500, 100, 20000);
        MAX_PATHFINDS_PER_TICK = b.defineInRange("max_pathfinds_per_tick", 6, 1, 64);
        CLEANUP_BUILT_BLOCKS = b.define("cleanup_built_blocks", true);
        b.pop();
        SPEC = b.build();
    }
    private NdConfig() {}
}
