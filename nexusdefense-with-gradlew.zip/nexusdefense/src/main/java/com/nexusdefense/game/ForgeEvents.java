package com.nexusdefense.game;

import com.nexusdefense.game.blockentity.NexusBlockEntity;
import com.nexusdefense.game.entity.InvaderEntity;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 侵略者の死亡・消失を Wave の Phase カウンターへ通知する（サーバー側のみ）。 */
@Mod.EventBusSubscriber(modid = NexusDefenseMod.MOD_ID)
public final class ForgeEvents {
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof InvaderEntity inv && !inv.level().isClientSide) {
            NexusBlockEntity be = inv.nexusBe();
            if (be != null) be.sessionDied(inv.getUUID());
        }
    }

    @SubscribeEvent
    public static void onLeave(EntityLeaveLevelEvent e) {
        if (e.getEntity() instanceof InvaderEntity inv && !e.getLevel().isClientSide) {
            NexusBlockEntity be = inv.nexusBe();
            if (be != null) be.sessionLost(inv.getUUID());        // 死亡後は alive から外れているので二重計上されない
        }
    }
    private ForgeEvents() {}
}
