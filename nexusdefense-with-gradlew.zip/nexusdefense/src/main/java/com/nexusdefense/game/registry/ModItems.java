package com.nexusdefense.game.registry;

import com.nexusdefense.game.MobSpec;
import com.nexusdefense.game.NexusDefenseMod;
import net.minecraft.world.item.*;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.*;

import java.util.*;

/**
 * 通常アイテムは「テクスチャ確認用」。効果は付けない（nexus_catalyst だけは NexusCoreBlock が使う）。
 * 設置ブロックは同じ ID の BlockItem、Mobは <id>_spawn_egg を登録する。
 */
public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, NexusDefenseMod.MOD_ID);

    public static final List<String> PLAIN_IDS = List.of("nexus_catalyst", "strong_catalyst", "stable_catalyst",
        "boss_catalyst", "small_remnants", "rift_flux", "nexus_shard", "defense_token", "engineer_hammer",
        "material_probe", "repair_kit", "defense_potion", "rally_banner", "nexus_compass");

    public static final Map<String, RegistryObject<Item>> PLAIN = new LinkedHashMap<>();
    public static final Map<String, RegistryObject<Item>> BLOCK_ITEMS = new LinkedHashMap<>();
    public static final Map<String, RegistryObject<Item>> EGGS = new LinkedHashMap<>();
    public static final RegistryObject<Item> NEXUS_CATALYST;

    static {
        for (String id : PLAIN_IDS)
            PLAIN.put(id, ITEMS.register(id, () -> new Item(new Item.Properties().stacksTo(
                id.endsWith("catalyst") ? 16 : id.equals("engineer_hammer") || id.equals("material_probe") ? 1 : 64))));
        NEXUS_CATALYST = PLAIN.get("nexus_catalyst");
        for (String id : ModBlocks.IDS)
            BLOCK_ITEMS.put(id, ITEMS.register(id, () -> new BlockItem(ModBlocks.ALL.get(id).get(), new Item.Properties())));
        for (MobSpec s : MobSpec.ALL)
            EGGS.put(s.id(), ITEMS.register(s.id() + "_spawn_egg",
                () -> new ForgeSpawnEggItem(ModEntities.TYPES.get(s.id()), s.eggMain(), s.eggSpot(), new Item.Properties())));
    }
    private ModItems() {}
}
