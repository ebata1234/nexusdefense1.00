package com.nexusdefense.game.entity;

import com.nexusdefense.core.ai.*;
import com.nexusdefense.core.common.CellPos;
import com.nexusdefense.game.NdConfig;
import com.nexusdefense.game.blockentity.NexusBlockEntity;
import com.nexusdefense.game.service.AiBudgetGate;
import com.nexusdefense.game.service.LevelWorldView;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.List;
import java.util.Optional;

/**
 * 使命: Nexus へ向かう。core の AStarPlanner で経路を計画し、各エッジ(WALK/JUMP/DROP/CLIMB/DIG/BRIDGE/LADDER/TOWER)を
 * 実世界で実行する。各ステップの直前に EdgeGenerator.revalidate() で前提を再検証し、崩れたら再計画する。
 * 【試作の限界】探索は同期実行（1tickあたりの件数を AiBudgetGate で制限）。時間分割A*は未実装。
 */
public class InvaderBrainGoal extends Goal {
    private static final AStarPlanner PLANNER = new AStarPlanner();
    private static final EdgeGenerator EDGES = new EdgeGenerator();

    private final InvaderEntity mob;
    private PathPlan plan;
    private int idx;
    private PathStep cur;
    private int phase, digIndex, digProgress, replanCooldown, stuckStage;
    private long readyTick;
    private Vec3 lastPos;
    private BlockPos crackPos;
    private boolean forceDig;

    public InvaderBrainGoal(InvaderEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override public boolean canUse() { return mob.nexusPos() != null && !mob.level().isClientSide; }
    @Override public boolean canContinueToUse() { return canUse(); }
    @Override public void stop() { clearCrack(); plan = null; cur = null; }

    private MobProfile profile() { return forceDig ? mob.profile().withEdge(EdgeType.DIG, 1.0) : mob.profile(); }
    private static BlockPos pos(CellPos c) { return new BlockPos(c.x(), c.y(), c.z()); }
    private CellPos here() { return new CellPos(mob.getBlockX(), mob.getBlockY(), mob.getBlockZ()); }

    @Override public void tick() {
        if (!(mob.level() instanceof ServerLevel level)) return;
        BlockPos nexus = mob.nexusPos();
        Vec3 nc = Vec3.atCenterOf(nexus);
        if (mob.distanceToSqr(nc) <= 6.25) { attackNexus(nc); return; }          // 到達: Nexus を攻撃
        checkStuck(level);
        if (replanCooldown > 0) replanCooldown--;
        if (plan == null || idx >= plan.steps().size()) {
            if (!tryPlan(level)) {                                                // 計画できない間は Nexus 方向へ素直に進む
                mob.getMoveControl().setWantedPosition(nc.x, mob.getY(), nc.z, 1.0);
                return;
            }
        }
        runStep(level);
    }

    private void attackNexus(Vec3 nc) {
        mob.getNavigation().stop();
        mob.getLookControl().setLookAt(nc.x, nc.y, nc.z);
        if (mob.tickCount % 20 == 0) {
            mob.swing(InteractionHand.MAIN_HAND);
            NexusBlockEntity be = mob.nexusBe();
            if (be != null) be.damageFromInvader(Math.max(1.0, mob.getAttributeValue(Attributes.ATTACK_DAMAGE)));
        }
    }

    private boolean tryPlan(ServerLevel level) {
        if (replanCooldown > 0 || !AiBudgetGate.tryAcquire(level.getGameTime())) return false;
        BlockPos n = mob.nexusPos();
        plan = PLANNER.plan(new LevelWorldView(level), profile(), here(), new CellPos(n.getX(), n.getY(), n.getZ()),
            1, NdConfig.MAX_PATH_NODES.get(), 64);
        idx = 0; cur = null; phase = 0; replanCooldown = 20;
        return !plan.steps().isEmpty();
    }

    private void invalidate() { plan = null; cur = null; clearCrack(); readyTick = 0; replanCooldown = 5; }
    private void advance() { idx++; cur = null; readyTick = 0; clearCrack(); }

    private void runStep(ServerLevel level) {
        if (cur == null) {                                                         // 新しいステップの開始: 再検証
            PathStep planned = plan.steps().get(idx);
            if (here().chebyshev(planned.from()) > 1) { invalidate(); return; }      // 位置がずれた
            Optional<PathStep> fresh = EDGES.revalidate(new LevelWorldView(level), profile(), planned);
            if (fresh.isEmpty()) { invalidate(); return; }
            cur = fresh.get(); phase = 0; digIndex = 0; digProgress = 0;
        }
        switch (cur.edge()) {
            case WALK, JUMP, DROP, CLIMB -> moveStep();
            case DIG -> digStep(level);
            case BRIDGE -> bridgeStep(level);
            case LADDER -> ladderStep(level);
            case TOWER -> towerStep(level);
        }
    }

    private boolean arrived(CellPos to) {
        return mob.getBlockX() == to.x() && mob.getBlockZ() == to.z() && Math.abs(mob.getY() - to.y()) < 0.9;
    }

    private void moveStep() {
        CellPos to = cur.to();
        if (arrived(to)) { advance(); return; }
        mob.getMoveControl().setWantedPosition(to.x() + 0.5, to.y(), to.z() + 0.5, 1.0);   // 目標が上なら MoveControl がジャンプ/はしご登りをする
    }

    // ------------------------------------------------------------ DIG
    private void digStep(ServerLevel level) {
        List<CellPos> breaks = cur.breaks();
        if (digIndex >= breaks.size()) { moveStep(); return; }
        BlockPos bp = pos(breaks.get(digIndex));
        BlockState st = level.getBlockState(bp);
        if (st.isAir() || st.getCollisionShape(level, bp).isEmpty()) { digIndex++; digProgress = 0; clearCrack(); return; }
        float hardness = st.getDestroySpeed(level, bp);
        if (hardness < 0) { invalidate(); return; }                                // 保護ブロックは壊さない
        if (mob.distanceToSqr(Vec3.atCenterOf(bp)) > 16.0) {                       // 4ブロック以内でないと採掘できない
            CellPos f = cur.from();
            mob.getMoveControl().setWantedPosition(f.x() + 0.5, f.y(), f.z() + 0.5, 1.0);
            return;
        }
        mob.getNavigation().stop();
        mob.getLookControl().setLookAt(Vec3.atCenterOf(bp));
        double needed = Math.max(1.0, hardness * 30.0 / profile().miningSpeed());  // コスト式と同じ: 強度×30÷採掘速度 [tick]
        digProgress++;
        crackPos = bp;
        level.destroyBlockProgress(mob.getId(), bp, Math.min(9, (int) (digProgress * 10 / needed)));
        if (digProgress % 8 == 0) mob.swing(InteractionHand.MAIN_HAND);
        if (digProgress >= needed) {
            clearCrack();
            level.destroyBlock(bp, false, mob);
            digIndex++; digProgress = 0;
        }
    }

    private void clearCrack() {
        if (crackPos != null && mob.level() instanceof ServerLevel l) l.destroyBlockProgress(mob.getId(), crackPos, -1);
        crackPos = null;
    }

    // ------------------------------------------------------------ BRIDGE / LADDER / TOWER
    private boolean reserve(BlockPos p, long now) {
        NexusBlockEntity be = mob.nexusBe();
        if (be == null) return true;
        if (be.reservations().isReservedByOther(mob.getUUID(), new CellPos(p.getX(), p.getY(), p.getZ()), now)) return false;
        be.reservations().tryReserve(mob.getUUID(), java.util.Set.of(new CellPos(p.getX(), p.getY(), p.getZ())), now, 200);
        return true;
    }

    private void placed(ServerLevel level, BlockPos p, BlockState s) {
        level.setBlock(p, s, 3);
        level.playSound(null, p, SoundEvents.STONE_PLACE, SoundSource.HOSTILE, 1.0f, 1.0f);
        mob.swing(InteractionHand.MAIN_HAND);
        NexusBlockEntity be = mob.nexusBe();
        if (be != null) be.markBuilt(p);
    }

    private void bridgeStep(ServerLevel level) {
        if (phase == 0) {
            BlockPos p = pos(cur.place());
            long now = level.getGameTime();
            if (!reserve(p, now)) return;                                          // 他のEngineerが予約中 → 待つ
            if (readyTick == 0) readyTick = now + (long) profile().placeIntervalTicks();
            mob.getNavigation().stop();
            mob.getLookControl().setLookAt(Vec3.atCenterOf(p));
            if (now < readyTick) return;
            if (!level.getBlockState(p).canBeReplaced()) { invalidate(); return; }
            placed(level, p, Blocks.COBBLESTONE.defaultBlockState());
            phase = 1;
        }
        moveStep();
    }

    private void ladderStep(ServerLevel level) {
        if (phase == 0) {
            BlockPos p = pos(cur.place());
            long now = level.getGameTime();
            if (!reserve(p, now)) return;
            if (readyTick == 0) readyTick = now + (long) profile().placeIntervalTicks();
            if (now < readyTick) return;
            if (!level.getBlockState(p).canBeReplaced()) { invalidate(); return; }
            Direction facing = null;
            for (Direction d : Direction.Plane.HORIZONTAL) {
                BlockPos w = p.relative(d);
                if (level.getBlockState(w).isFaceSturdy(level, w, d.getOpposite())) { facing = d.getOpposite(); break; }
            }
            BlockState ls = facing == null ? null : Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, facing);
            if (ls == null || !ls.canSurvive(level, p)) { invalidate(); return; }
            placed(level, p, ls);
            phase = 1;
        }
        moveStep();                                                                // はしごを登る（MoveControl のジャンプ→onClimbable）
    }

    private int towerTicks;
    private void towerStep(ServerLevel level) {
        CellPos from = cur.from();
        BlockPos fp = pos(from);
        if (phase == 0) {                                                          // 足元セルで接地するのを待ってジャンプ
            if (mob.onGround() && mob.getBlockX() == from.x() && mob.getBlockZ() == from.z()
                && level.getGameTime() >= readyTick) {
                if (!reserve(fp, level.getGameTime())) return;
                mob.getJumpControl().jump(); phase = 1; towerTicks = 0;
            }
            if (readyTick == 0) readyTick = level.getGameTime() + 6;
            return;
        }
        if (phase == 1) {                                                          // 頂点付近でバウンディングボックスが抜けたら足元に設置
            towerTicks++;
            if (mob.getY() >= from.y() + 1.0) {
                if (!level.getBlockState(fp).canBeReplaced()) { invalidate(); return; }
                placed(level, fp, Blocks.COBBLESTONE.defaultBlockState());
                phase = 2;
            } else if (towerTicks > 20) { phase = 0; readyTick = level.getGameTime() + 10; }   // 跳べなかった → やり直し
            return;
        }
        moveStep();                                                                // 着地して到達セルに乗る
    }

    // ------------------------------------------------------------ 停滞回復（4段階の簡易版）
    private void checkStuck(ServerLevel level) {
        if (mob.tickCount % 40 != 0) return;
        Vec3 p = mob.position();
        boolean working = digProgress > 0 || readyTick != 0;
        if (lastPos != null && p.distanceToSqr(lastPos) < 0.25 && !working) {
            stuckStage++;
            switch (Math.min(stuckStage, 3)) {
                case 1 -> invalidate();                                            // 段階1: 再計画
                case 2 -> { forceDig = true; invalidate(); }                       // 段階2: DIGを許可して再計画
                default -> { forceDig = false; stuckStage = 0; invalidate(); }     // 段階3以降: 試作では再計画のみ（強制掘削・再配置は未実装）
            }
        } else if (lastPos != null && p.distanceToSqr(lastPos) >= 0.25) { stuckStage = 0; forceDig = false; }
        lastPos = p;
    }
}
