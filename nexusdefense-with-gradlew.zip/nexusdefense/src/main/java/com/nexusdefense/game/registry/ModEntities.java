package com.nexusdefense.game.registry;

import com.nexusdefense.game.MobSpec;
import com.nexusdefense.game.NexusDefenseMod;
import com.nexusdefense.game.entity.InvaderEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.*;

import java.util.*;

/** Mob 1種につき 1 EntityType（ID = VisualPack の geo/animation/texture/lang 名）。クラスは InvaderEntity を共用。 */
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, NexusDefenseMod.MOD_ID);
    public static final Map<String, RegistryObject<EntityType<InvaderEntity>>> TYPES = new LinkedHashMap<>();

    static {
        for (MobSpec s : MobSpec.ALL)
            TYPES.put(s.id(), ENTITIES.register(s.id(), () ->
                EntityType.Builder.<InvaderEntity>of(InvaderEntity::new, MobCategory.MONSTER)
                    .sized(s.width(), s.height()).clientTrackingRange(10)
                    .build(NexusDefenseMod.MOD_ID + ":" + s.id())));
    }
    private ModEntities() {}
}
