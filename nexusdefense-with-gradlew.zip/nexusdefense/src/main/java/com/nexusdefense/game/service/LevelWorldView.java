package com.nexusdefense.game.service;

import com.nexusdefense.core.ai.BlockInfo;
import com.nexusdefense.core.ai.WorldView;
import com.nexusdefense.core.common.CellPos;
import com.nexusdefense.game.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashMap;
import java.util.Map;

/** AI層の WorldView を Level で実装するアダプター。1回の探索の間だけ生存し、読み出しをキャッシュする。 */
public final class LevelWorldView implements WorldView {
    private final Level level;
    private final Map<Long, BlockInfo> cache = new HashMap<>();

    public LevelWorldView(Level level) { this.level = level; }

    @Override public BlockInfo block(CellPos c) {
        long key = BlockPos.asLong(c.x(), c.y(), c.z());
        BlockInfo b = cache.get(key);
        if (b == null) { b = read(new BlockPos(c.x(), c.y(), c.z())); cache.put(key, b); }
        return b;
    }

    private BlockInfo read(BlockPos p) {
        if (level.isOutsideBuildHeight(p) || !level.hasChunkAt(p)) return BlockInfo.BEDROCK;   // 未ロードは通行不可
        BlockState s = level.getBlockState(p);
        if (s.is(Blocks.LADDER)) return BlockInfo.LADDER;
        if (s.is(ModBlocks.NEXUS_CORE.get())) return BlockInfo.BEDROCK;                         // Nexus は壊せない
        if (!s.getFluidState().isEmpty()) return BlockInfo.HAZARD;                              // 水・溶岩は試作では危険扱い
        if (s.isAir() || s.getCollisionShape(level, p).isEmpty()) return BlockInfo.AIR;
        float hardness = s.getDestroySpeed(level, p);
        return hardness < 0 ? BlockInfo.BEDROCK : BlockInfo.solid(hardness);
    }

    @Override public int minY() { return level.getMinBuildHeight(); }
    @Override public int maxY() { return level.getMaxBuildHeight() - 1; }
}
