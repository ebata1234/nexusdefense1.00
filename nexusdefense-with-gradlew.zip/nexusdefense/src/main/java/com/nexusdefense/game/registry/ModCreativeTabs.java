package com.nexusdefense.game.registry;

import com.nexusdefense.game.NexusDefenseMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraftforge.registries.*;

/** ゲーム内でテクスチャを一覧確認するためのクリエイティブタブ。 */
public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, NexusDefenseMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
        .title(Component.translatable("itemGroup.nexusdefense"))
        .icon(() -> new ItemStack(ModItems.BLOCK_ITEMS.get("nexus_core").get()))
        .displayItems((params, out) -> {
            ModItems.BLOCK_ITEMS.values().forEach(r -> out.accept(r.get()));
            ModItems.PLAIN.values().forEach(r -> out.accept(r.get()));
            ModItems.EGGS.values().forEach(r -> out.accept(r.get()));
        }).build());
    private ModCreativeTabs() {}
}
