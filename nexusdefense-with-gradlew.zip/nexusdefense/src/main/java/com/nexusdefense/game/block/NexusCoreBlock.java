package com.nexusdefense.game.block;

import com.nexusdefense.game.blockentity.NexusBlockEntity;
import com.nexusdefense.game.registry.ModBlockEntities;
import com.nexusdefense.game.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

/**
 * Nexus Core。見た目は VisualPack の block model（北面が正面・向き固定）。
 * 試作では GUI を持たず、右クリックで操作する:
 *   触媒を持って右クリック=開始 / 素手でShift+右クリック=停止 / 素手で右クリック=状態表示
 */
public class NexusCoreBlock extends BaseEntityBlock {
    public NexusCoreBlock(Properties p) { super(p); }

    @Override public RenderShape getRenderShape(BlockState s) { return RenderShape.MODEL; }   // BaseEntityBlock の既定は INVISIBLE

    @Nullable @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState st) { return new NexusBlockEntity(pos, st); }

    @Nullable @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level lvl, BlockState st, BlockEntityType<T> type) {
        return lvl.isClientSide ? null : createTickerHelper(type, ModBlockEntities.NEXUS_CORE.get(), NexusBlockEntity::serverTick);
    }

    @Override
    public InteractionResult use(BlockState st, Level lvl, BlockPos pos, Player pl, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (lvl.isClientSide) return InteractionResult.SUCCESS;
        if (!(lvl.getBlockEntity(pos) instanceof NexusBlockEntity nbe) || !(pl instanceof ServerPlayer sp)) return InteractionResult.PASS;
        ItemStack held = pl.getItemInHand(hand);
        if (held.is(ModItems.NEXUS_CATALYST.get())) {
            if (nbe.tryStart(sp) && !pl.getAbilities().instabuild) held.shrink(1);   // サーバー側で検証してから消費
        } else if (pl.isShiftKeyDown() && held.isEmpty()) nbe.stop(sp);
        else nbe.sendStatus(sp);
        return InteractionResult.CONSUME;
    }
}
