package com.nexusdefense.game;

import java.util.List;

/** 試作の敵一覧。id は VisualPack の geo / animation / texture / lang 名と一致させる。 */
public record MobSpec(String id, double health, double damage, double speed, float width, float height,
                      int eggMain, int eggSpot, boolean glow) {
    public static final List<MobSpec> ALL = List.of(
        new MobSpec("zombie",         20, 3, 0.23, 0.6f, 1.95f, 0x4a7a4a, 0x2a3f2a, false),
        new MobSpec("zombie_miner",   20, 3, 0.23, 0.6f, 1.95f, 0x7a6a4a, 0xc8a050, false),
        new MobSpec("engineer",       14, 2, 0.23, 0.6f, 1.95f, 0xc87a30, 0x30c8c8, false),
        new MobSpec("armored_zombie", 40, 4, 0.21, 0.7f, 2.00f, 0x707070, 0x4a7a4a, false),
        new MobSpec("zombie_brute",   60, 6, 0.20, 0.9f, 2.30f, 0x5a3a3a, 0xb04040, false),
        new MobSpec("tar_zombie",     30, 3, 0.19, 0.7f, 1.90f, 0x202020, 0x505030, false),
        new MobSpec("skeleton",       14, 2, 0.25, 0.6f, 1.99f, 0xd8d8d0, 0x808080, false),
        new MobSpec("creeper",        20, 0, 0.25, 0.6f, 1.70f, 0x30a030, 0x000000, false),
        new MobSpec("spider",         16, 3, 0.30, 1.4f, 0.90f, 0x302020, 0xa02020, false),
        new MobSpec("blue_spider",    20, 3, 0.30, 1.4f, 0.90f, 0x2040a0, 0x60c0ff, false),
        new MobSpec("mother_spider",  60, 4, 0.25, 2.0f, 1.20f, 0x402030, 0xe0a0ff, false),
        new MobSpec("burrower",       24, 3, 0.22, 1.0f, 0.80f, 0x6a4a2a, 0xa08060, false),
        new MobSpec("pit_colossus",  400, 12, 0.20, 4.0f, 6.00f, 0x3a2a4a, 0xff8030, true));

    public static MobSpec byId(String id) {
        for (MobSpec s : ALL) if (s.id().equals(id)) return s;
        return ALL.get(0);
    }
}
