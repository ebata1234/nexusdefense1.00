package com.nexusdefense.game.registry;

import com.nexusdefense.game.NexusDefenseMod;
import com.nexusdefense.game.block.NexusCoreBlock;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.*;

import java.util.*;

/** VisualPack の blockstates / models / textures と同じ ID で登録する。 */
public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, NexusDefenseMod.MOD_ID);
    public static final Map<String, RegistryObject<Block>> ALL = new LinkedHashMap<>();
    public static final List<String> IDS = List.of("nexus_core", "reinforced_wall", "defense_beacon", "arrow_tower",
        "guard_tower", "spike_trap", "flame_trap", "slow_trap", "explosive_trap", "supply_crate", "warning_light");

    public static final RegistryObject<Block> NEXUS_CORE;

    static {
        for (String id : IDS) ALL.put(id, BLOCKS.register(id, () -> create(id)));
        NEXUS_CORE = ALL.get("nexus_core");
    }

    private static Block create(String id) {
        BlockBehaviour.Properties p = switch (id) {
            case "nexus_core" -> BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN)
                .strength(4.0f, 1200.0f).sound(SoundType.DEEPSLATE).lightLevel(s -> 10).noOcclusion();
            // AIのDIGコストは見た目ではなくブロック強度テーブルで決まる。ここでは硬さだけ設定。
            case "reinforced_wall" -> BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                .strength(10.0f, 40.0f).sound(SoundType.NETHERITE_BLOCK).requiresCorrectToolForDrops();
            case "defense_beacon" -> BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN)
                .strength(3.0f, 6.0f).sound(SoundType.METAL).lightLevel(s -> 12).noOcclusion();
            case "warning_light" -> BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED)
                .strength(2.0f, 3.0f).sound(SoundType.METAL).lightLevel(s -> 14).noOcclusion();
            case "supply_crate" -> BlockBehaviour.Properties.of().mapColor(MapColor.WOOD)
                .strength(2.0f, 3.0f).sound(SoundType.WOOD);
            default -> BlockBehaviour.Properties.of().mapColor(MapColor.STONE)
                .strength(3.0f, 6.0f).sound(SoundType.STONE).noOcclusion();
        };
        return id.equals("nexus_core") ? new NexusCoreBlock(p) : new Block(p);
    }
    private ModBlocks() {}
}
