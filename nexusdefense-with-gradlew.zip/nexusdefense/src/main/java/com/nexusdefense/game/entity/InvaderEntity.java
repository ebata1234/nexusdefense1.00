package com.nexusdefense.game.entity;

import com.nexusdefense.core.ai.MobProfile;
import com.nexusdefense.core.ai.MobProfiles;
import com.nexusdefense.game.MobSpec;
import com.nexusdefense.game.blockentity.NexusBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * 侵略者。13種すべてこのクラスを共用し、mobId（= EntityType の登録名）で見た目・能力・AIプロファイルを切り替える。
 * 見た目は GeckoLib（geo / animation / texture は VisualPack の同名ファイル）。
 */
public class InvaderEntity extends Zombie implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private BlockPos nexusPos;
    private int wave = 1;

    public InvaderEntity(EntityType<? extends InvaderEntity> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder attributes(MobSpec s) {
        return Zombie.createAttributes()
            .add(Attributes.MAX_HEALTH, s.health()).add(Attributes.ATTACK_DAMAGE, s.damage())
            .add(Attributes.MOVEMENT_SPEED, s.speed()).add(Attributes.FOLLOW_RANGE, 40.0);
    }

    public String mobId() {
        ResourceLocation k = ForgeRegistries.ENTITY_TYPES.getKey(getType());
        return k == null ? "zombie" : k.getPath();
    }
    public MobProfile profile() { return MobProfiles.byId(mobId()); }
    @Nullable public BlockPos nexusPos() { return nexusPos; }

    /** Wave に紐付けて初期化（HP・攻撃力のWave補正: 1+0.04×Wave、上限4倍）。 */
    public void bindToNexus(BlockPos pos, int wave) {
        this.nexusPos = pos; this.wave = wave;
        MobSpec s = MobSpec.byId(mobId());
        double scale = Math.min(4.0, 1.0 + 0.04 * wave);
        AttributeInstance hp = getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) hp.setBaseValue(s.health() * scale);
        AttributeInstance atk = getAttribute(Attributes.ATTACK_DAMAGE);
        if (atk != null) atk.setBaseValue(s.damage() * scale);
        setHealth(getMaxHealth());
        switch (mobId()) {
            case "zombie_miner" -> setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_PICKAXE));
            case "engineer" -> setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.COBBLESTONE));
            default -> {}
        }
        setDropChance(EquipmentSlot.MAINHAND, 0.0f);
        setPersistenceRequired();
    }

    @Nullable public NexusBlockEntity nexusBe() {
        if (nexusPos == null || !level().isLoaded(nexusPos)) return null;
        BlockEntity be = level().getBlockEntity(nexusPos);
        return be instanceof NexusBlockEntity n ? n : null;
    }

    // ---------------- AI: 使命(InvaderBrainGoal) + 日和見(近くのプレイヤー/被弾時の反撃)
    @Override protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, false));
        this.goalSelector.addGoal(2, new InvaderBrainGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
            e -> nexusPos != null && e.distanceToSqr(this) < 36.0));    // Nexus に紐付いた個体のみ、6ブロック以内のプレイヤーを攻撃
    }

    @Override protected boolean isSunSensitive() { return false; }
    @Override protected boolean convertsInWater() { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }

    @Override public void tick() {
        super.tick();
        // Nexus に紐付いているのに追跡されていない個体(再読込・停止後の孤児)は消す
        if (!level().isClientSide && nexusPos != null && tickCount % 100 == 0 && level().isLoaded(nexusPos)) {
            NexusBlockEntity be = nexusBe();
            if (be == null || !be.isRunning() || !be.tracks(getUUID())) discard();
        }
    }

    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (nexusPos != null) tag.put("NexusPos", NbtUtils.writeBlockPos(nexusPos));
        tag.putInt("InvasionWave", wave);
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("NexusPos")) nexusPos = NbtUtils.readBlockPos(tag.getCompound("NexusPos"));
        wave = tag.getInt("InvasionWave");
    }

    // ---------------- GeckoLib アニメーション: animation.nexusdefense.<id>.idle / .walk
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 4, state -> {
            String id = mobId();
            if (id.equals("pit_colossus")) return PlayState.STOP;      // 現状アニメーション未同梱
            return state.setAndContinue(RawAnimation.begin()
                .thenLoop("animation.nexusdefense." + id + (state.isMoving() ? ".walk" : ".idle")));
        }));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
