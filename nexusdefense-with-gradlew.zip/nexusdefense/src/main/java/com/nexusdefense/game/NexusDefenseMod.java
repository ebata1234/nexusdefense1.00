package com.nexusdefense.game;

import com.nexusdefense.game.registry.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

@Mod(NexusDefenseMod.MOD_ID)
public class NexusDefenseMod {
    public static final String MOD_ID = "nexusdefense";

    public NexusDefenseMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModCreativeTabs.TABS.register(bus);
        bus.addListener(this::onAttributes);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, NdConfig.SPEC);
    }

    private void onAttributes(EntityAttributeCreationEvent e) {
        for (MobSpec s : MobSpec.ALL)
            e.put(ModEntities.TYPES.get(s.id()).get(), com.nexusdefense.game.entity.InvaderEntity.attributes(s).build());
    }
}
