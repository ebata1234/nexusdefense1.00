package com.nexusdefense.client;

import com.nexusdefense.client.renderer.InvaderRenderer;
import com.nexusdefense.client.renderer.PitColossusRenderer;
import com.nexusdefense.game.MobSpec;
import com.nexusdefense.game.NexusDefenseMod;
import com.nexusdefense.game.registry.ModEntities;
import net.minecraft.client.renderer.entity.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** クライアント専用。Dedicated Server では読み込まれない（value = Dist.CLIENT）。 */
@Mod.EventBusSubscriber(modid = NexusDefenseMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        for (MobSpec s : MobSpec.ALL) {
            var type = ModEntities.TYPES.get(s.id()).get();
            if (s.glow()) e.registerEntityRenderer(type, PitColossusRenderer::new);
            else e.registerEntityRenderer(type, InvaderRenderer::new);
        }
    }
    private ClientSetup() {}
}
