package com.nexusdefense.client.renderer;

import com.nexusdefense.game.entity.InvaderEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class InvaderRenderer extends GeoEntityRenderer<InvaderEntity> {
    public InvaderRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new InvaderModel());
        this.shadowRadius = 0.5f;
    }
}
