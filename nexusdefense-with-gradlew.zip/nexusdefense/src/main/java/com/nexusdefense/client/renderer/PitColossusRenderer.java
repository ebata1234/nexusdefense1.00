package com.nexusdefense.client.renderer;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** Pit Colossus は pit_colossus_glowmask.png による発光レイヤー付き（AutoGlowingGeoLayer は <texture>_glowmask.png を自動で探す）。 */
public class PitColossusRenderer extends InvaderRenderer {
    public PitColossusRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
        this.shadowRadius = 2.0f;
    }
}
