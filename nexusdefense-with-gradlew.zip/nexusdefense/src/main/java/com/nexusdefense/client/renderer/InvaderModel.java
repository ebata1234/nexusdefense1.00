package com.nexusdefense.client.renderer;

import com.nexusdefense.game.NexusDefenseMod;
import com.nexusdefense.game.entity.InvaderEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

/** mobId から VisualPack の geo / texture / animation を引く。 */
public class InvaderModel extends GeoModel<InvaderEntity> {
    @Override public ResourceLocation getModelResource(InvaderEntity e) {
        return new ResourceLocation(NexusDefenseMod.MOD_ID, "geo/" + e.mobId() + ".geo.json");
    }
    @Override public ResourceLocation getTextureResource(InvaderEntity e) {
        return new ResourceLocation(NexusDefenseMod.MOD_ID, "textures/entity/" + e.mobId() + ".png");
    }
    @Override public ResourceLocation getAnimationResource(InvaderEntity e) {
        return new ResourceLocation(NexusDefenseMod.MOD_ID, "animations/" + e.mobId() + ".animation.json");
    }
}
