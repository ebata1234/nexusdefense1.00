package com.nexusdefense.core.ai;

import com.nexusdefense.core.common.CellPos;

/** AIが世界を読む唯一の窓口。game層が Level で実装し、テストでは InMemoryWorld を使う。 */
public interface WorldView {
    BlockInfo block(CellPos pos);
    int minY();
    int maxY();
    default boolean inBounds(CellPos p) { return p.y() >= minY() && p.y() <= maxY(); }
}
