package com.nexusdefense.core.common;

/** 乱数の抽象。種を固定すればテスト・再現ができる。 */
public interface Rng {
    double nextDouble();
    int nextInt(int bound);
    long nextLong();
}
