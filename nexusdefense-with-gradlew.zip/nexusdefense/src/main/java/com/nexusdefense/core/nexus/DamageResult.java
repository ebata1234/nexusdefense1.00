package com.nexusdefense.core.nexus;

public record DamageResult(Outcome outcome, double applied, double remaining, boolean lethal) {
    public enum Outcome { APPLIED, REJECTED_STATE, REJECTED_INVALID }
}
