package com.nexusdefense.core.decision;

public record Selection(boolean switched, ActionCandidate chosen) {
    public static Selection keep() { return new Selection(false, null); }
    public static Selection switchTo(ActionCandidate c) { return new Selection(true, c); }
}
