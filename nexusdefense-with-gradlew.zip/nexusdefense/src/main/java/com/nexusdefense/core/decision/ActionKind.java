package com.nexusdefense.core.decision;
public enum ActionKind { ATTACK_NEXUS, SIEGE_SHOOT, DETONATE, FOLLOW_PLAN, DIG_BLOCKER, BUILD_CROSSING,
                         ATTACK_PLAYER, ATTACK_ENTITY, REPOSITION, HOLD_BACK }
