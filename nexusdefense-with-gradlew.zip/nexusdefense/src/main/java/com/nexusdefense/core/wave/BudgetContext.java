package com.nexusdefense.core.wave;
public record BudgetContext(int wave, int playerCount, double difficulty, double catalystMultiplier) {}
