package com.nexusdefense.core.ai;

/** AIが見るブロック情報。strength は破壊時間の基準（石=1.5, 黒曜石=50）。 */
public record BlockInfo(BlockKind kind, double strength) {
    public static final BlockInfo AIR = new BlockInfo(BlockKind.AIR, 0);
    public static final BlockInfo LADDER = new BlockInfo(BlockKind.LADDER, 0.4);
    public static final BlockInfo HAZARD = new BlockInfo(BlockKind.HAZARD, 0);
    public static final BlockInfo BEDROCK = new BlockInfo(BlockKind.PROTECTED, Double.POSITIVE_INFINITY);
    public static BlockInfo solid(double strength) { return new BlockInfo(BlockKind.SOLID, strength); }
    public static final BlockInfo STONE = solid(1.5);
    public static final BlockInfo DIRT = solid(0.5);
    public static final BlockInfo OBSIDIAN = solid(50.0);

    public boolean passable() { return kind == BlockKind.AIR || kind == BlockKind.LADDER; }
    public boolean standable() { return kind == BlockKind.SOLID || kind == BlockKind.PROTECTED; }
    public boolean breakable() { return kind == BlockKind.SOLID; }
}
