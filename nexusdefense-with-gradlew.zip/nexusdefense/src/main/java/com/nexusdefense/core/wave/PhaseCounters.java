package com.nexusdefense.core.wave;

/**
 * Phaseの複数カウンター。不変条件: planned == queued + pendingSpawn + spawned + failedFinal
 * 完了判定は「未発行0 かつ 結果待ち0 かつ 予定数==成功+失敗確定 かつ 生存0」。
 */
public final class PhaseCounters {
    int planned, queued, pendingSpawn, spawned, failedFinal, dead, lost, extra;

    public int planned() { return planned; }
    public int queued() { return queued; }
    public int pendingSpawn() { return pendingSpawn; }
    public int spawned() { return spawned; }
    public int failedFinal() { return failedFinal; }
    public int dead() { return dead; }
    public int lost() { return lost; }
    public int extra() { return extra; }

    public int alive() { return spawned + extra - dead - lost; }
    public boolean resolved() { return queued == 0 && pendingSpawn == 0 && planned == spawned + failedFinal; }
    public boolean cleared() { return resolved() && alive() == 0; }
    public boolean invariantHolds() { return planned == queued + pendingSpawn + spawned + failedFinal; }
}
