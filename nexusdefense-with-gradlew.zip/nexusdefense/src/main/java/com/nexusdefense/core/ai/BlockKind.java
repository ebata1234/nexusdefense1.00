package com.nexusdefense.core.ai;
public enum BlockKind { AIR, SOLID, LADDER, HAZARD, PROTECTED }
