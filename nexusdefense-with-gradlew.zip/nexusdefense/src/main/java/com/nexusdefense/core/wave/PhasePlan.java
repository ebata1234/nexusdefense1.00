package com.nexusdefense.core.wave;
import java.util.List;
public record PhasePlan(PhaseTheme theme, List<SpawnTicket> tickets, double spent, double unspent) {}
