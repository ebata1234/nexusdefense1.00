package com.nexusdefense.core.wave;

/** 予算式の係数。B(n) = (base + linear*n + quadratic*n^2) * 難度 * (1 + perExtraPlayer*(人数-1)) */
public record BudgetPolicy(double base, double linear, double quadratic, double perExtraPlayer,
                           int maxScaledPlayers, double[] phaseWeights, double carryOverCapRatio) {
    public static BudgetPolicy defaults() {
        return new BudgetPolicy(10, 5, 0.5, 0.15, 8, new double[]{0.25, 0.25, 0.25, 0.25}, 0.5);
    }
    public int phasesPerWave() { return phaseWeights.length; }
}
