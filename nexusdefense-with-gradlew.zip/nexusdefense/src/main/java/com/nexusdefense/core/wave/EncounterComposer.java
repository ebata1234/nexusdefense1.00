package com.nexusdefense.core.wave;

import com.nexusdefense.core.common.Rng;
import java.util.*;

/** 予算内で重み付き抽選により敵を編成する（設計書 2.3）。 */
public final class EncounterComposer {
    public static final int MAX_TICKETS = 300;
    private final MobCatalog catalog;
    private final ThemeCatalog themes;

    public EncounterComposer(MobCatalog catalog, ThemeCatalog themes) { this.catalog = catalog; this.themes = themes; }

    private List<MobDef> candidates(PhaseComposeRequest req) {
        List<MobDef> base = catalog.all().stream().filter(m -> m.minWave() <= req.wave()).toList();
        List<MobDef> themed = base.stream().filter(m -> m.themes().contains(req.theme())).toList();
        return themed.isEmpty() ? base : themed;
    }

    public PhasePlan compose(PhaseComposeRequest req, Rng rng) {
        ThemeCatalog.ThemeDef theme = themes.get(req.theme());
        List<MobDef> pool = candidates(req);
        List<SpawnTicket> tickets = new ArrayList<>();
        Map<Role, Integer> roleCount = new EnumMap<>(Role.class);
        Map<String, Integer> mobCount = new HashMap<>();
        double remaining = req.budget();

        while (tickets.size() < MAX_TICKETS) {
            List<MobDef> cands = new ArrayList<>();
            List<Double> weights = new ArrayList<>();
            double total = 0;
            for (MobDef m : pool) {
                if (m.cost() > remaining + 1e-9) continue;
                if (mobCount.getOrDefault(m.id(), 0) >= m.maxPerPhase()) continue;
                double w = theme.weight(m.role()) * m.baseWeight();
                if (w <= 0) continue;
                double cap = theme.capFraction(m.role());
                if (cap < 1.0 && roleCount.getOrDefault(m.role(), 0) + 1 > Math.max(1.0, cap * (tickets.size() + 1))) continue;
                cands.add(m); weights.add(w); total += w;
            }
            if (cands.isEmpty()) break;
            MobDef pick = choose(cands, weights, total, rng);
            tickets.add(ticket(pick, rng));
            remaining -= pick.cost();
            roleCount.merge(pick.role(), 1, Integer::sum);
            mobCount.merge(pick.id(), 1, Integer::sum);
        }
        return new PhasePlan(req.theme(), tickets, req.budget() - remaining, remaining);
    }

    /** スポーン失敗確定時の再抽選（1体）。返却予算内で置き換えられなければ empty。 */
    public Optional<SpawnTicket> reroll(SpawnTicket failed, double refund, PhaseComposeRequest req, Rng rng) {
        ThemeCatalog.ThemeDef theme = themes.get(req.theme());
        List<MobDef> cands = new ArrayList<>();
        List<Double> weights = new ArrayList<>();
        double total = 0;
        for (MobDef m : candidates(req)) {
            double w = theme.weight(m.role()) * m.baseWeight();
            if (m.cost() <= refund + 1e-9 && w > 0) { cands.add(m); weights.add(w); total += w; }
        }
        if (cands.isEmpty()) return Optional.empty();
        return Optional.of(ticket(choose(cands, weights, total, rng), rng));
    }

    private static MobDef choose(List<MobDef> cands, List<Double> weights, double total, Rng rng) {
        double r = rng.nextDouble() * total;
        for (int i = 0; i < cands.size(); i++) { r -= weights.get(i); if (r <= 0) return cands.get(i); }
        return cands.get(cands.size() - 1);
    }

    private static SpawnTicket ticket(MobDef m, Rng rng) {
        return new SpawnTicket(new UUID(rng.nextLong(), rng.nextLong()), m.id(), m.role(), m.cost());
    }
}
