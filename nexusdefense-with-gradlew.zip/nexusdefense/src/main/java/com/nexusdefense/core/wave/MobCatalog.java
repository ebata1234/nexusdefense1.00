package com.nexusdefense.core.wave;

import java.util.*;

public final class MobCatalog {
    private final List<MobDef> all;
    public MobCatalog(List<MobDef> all) { this.all = List.copyOf(all); }
    public List<MobDef> all() { return all; }
    public Optional<MobDef> get(String id) { return all.stream().filter(m -> m.id().equals(id)).findFirst(); }

    /** 試作用の初期カタログ（コストは Zombie=1.0 基準。仕様書の Engineer=6 に合わせる）。 */
    public static MobCatalog prototype() {
        Set<PhaseTheme> all4 = EnumSet.allOf(PhaseTheme.class);
        return new MobCatalog(List.of(
            new MobDef("zombie", Role.MELEE, 1.0, 1, all4, 1.0, 200),
            new MobDef("zombie_miner", Role.MINER, 3.0, 2, EnumSet.of(PhaseTheme.MELEE, PhaseTheme.SIEGE, PhaseTheme.MIXED), 1.0, 200),
            new MobDef("engineer", Role.ENGINEER, 6.0, 3, EnumSet.of(PhaseTheme.SIEGE, PhaseTheme.MIXED), 1.0, 200)));
    }
}
