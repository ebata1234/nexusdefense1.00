package com.nexusdefense.core.ai;

import java.util.List;

public record PathPlan(List<PathStep> steps, boolean partial, double totalCost, int expanded) {}
