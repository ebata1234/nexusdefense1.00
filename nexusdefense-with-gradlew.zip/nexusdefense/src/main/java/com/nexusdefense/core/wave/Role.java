package com.nexusdefense.core.wave;
public enum Role { MELEE, RANGED, SIEGE, ENGINEER, MINER, BURROWER, SUPPORT, SPECIAL, BOSS }
