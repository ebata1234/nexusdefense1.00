package com.nexusdefense.core.nexus;

public enum NexusState {
    INACTIVE, PREPARING, ACTIVE, WAVE_TRANSITION, PAUSED, DEFEATED, STOPPED, ERROR;

    public boolean isRunning() { return this == ACTIVE || this == WAVE_TRANSITION; }
    public boolean acceptsDamage() { return this == ACTIVE; }
}
