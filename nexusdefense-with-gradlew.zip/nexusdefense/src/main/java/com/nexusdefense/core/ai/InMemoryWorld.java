package com.nexusdefense.core.ai;

import com.nexusdefense.core.common.CellPos;
import java.util.HashMap;
import java.util.Map;

/** テスト用の格子世界。範囲外は岩盤（保護）として扱う。 */
public final class InMemoryWorld implements WorldView {
    private final Map<CellPos, BlockInfo> blocks = new HashMap<>();
    private final int minY, maxY;
    private int minX = Integer.MIN_VALUE, maxX = Integer.MAX_VALUE, minZ = Integer.MIN_VALUE, maxZ = Integer.MAX_VALUE;

    public InMemoryWorld(int minY, int maxY) { this.minY = minY; this.maxY = maxY; }

    public InMemoryWorld bounds(int minX, int maxX, int minZ, int maxZ) {
        this.minX = minX; this.maxX = maxX; this.minZ = minZ; this.maxZ = maxZ; return this;
    }
    public InMemoryWorld set(int x, int y, int z, BlockInfo b) { blocks.put(new CellPos(x, y, z), b); return this; }
    public InMemoryWorld set(CellPos p, BlockInfo b) { blocks.put(p, b); return this; }
    public InMemoryWorld fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockInfo b) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) blocks.put(new CellPos(x, y, z), b);
        return this;
    }

    @Override public BlockInfo block(CellPos p) {
        if (p.y() < minY || p.y() > maxY || p.x() < minX || p.x() > maxX || p.z() < minZ || p.z() > maxZ)
            return BlockInfo.BEDROCK;
        return blocks.getOrDefault(p, BlockInfo.AIR);
    }
    @Override public int minY() { return minY; }
    @Override public int maxY() { return maxY; }
}
