package com.nexusdefense.core.wave;

import java.util.Set;

/** 敵の定義（データ駆動化の対象）。cost は予算消費量。 */
public record MobDef(String id, Role role, double cost, int minWave, Set<PhaseTheme> themes,
                     double baseWeight, int maxPerPhase) {}
