package com.nexusdefense.core.common;

/** ブロック座標（Minecraft非依存）。AIの足元セルを表す。 */
public record CellPos(int x, int y, int z) {
    public CellPos offset(int dx, int dy, int dz) { return new CellPos(x + dx, y + dy, z + dz); }
    public CellPos above() { return offset(0, 1, 0); }
    public CellPos below() { return offset(0, -1, 0); }
    public int chebyshev(CellPos o) {
        return Math.max(Math.abs(x - o.x), Math.max(Math.abs(y - o.y), Math.abs(z - o.z)));
    }
}
