package com.nexusdefense.core.nexus;

public record TransitionResult(boolean accepted, NexusState from, NexusState to, String rejectReason) {
    static TransitionResult ok(NexusState from, NexusState to) { return new TransitionResult(true, from, to, null); }
    static TransitionResult rejected(NexusState from, String why) { return new TransitionResult(false, from, from, why); }
}
