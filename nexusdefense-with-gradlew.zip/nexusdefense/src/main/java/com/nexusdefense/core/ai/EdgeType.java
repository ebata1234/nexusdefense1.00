package com.nexusdefense.core.ai;
public enum EdgeType { WALK, JUMP, DROP, CLIMB, DIG, BRIDGE, LADDER, TOWER }
