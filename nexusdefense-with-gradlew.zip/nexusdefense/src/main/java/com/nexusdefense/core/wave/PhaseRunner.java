package com.nexusdefense.core.wave;

import com.nexusdefense.core.common.Rng;
import java.util.*;

/** 1つのPhaseの状態機械（設計書 2.4 の P1〜P8）。サーバーtickごとに tick() を呼ぶ。 */
public final class PhaseRunner {
    public interface SpawnGateway { void request(SpawnTicket ticket); }
    public record Settings(int gapTicks, int residualThreshold, int spawnsPerTick, int concurrentCap, int maxRetries) {
        public static Settings defaults() { return new Settings(200, 5, 3, 40, 3); }
    }

    private final PhaseComposeRequest req;
    private final EncounterComposer composer;
    private final SpawnGateway gateway;
    private final Rng rng;
    private final Settings st;
    private final long gapEnd;

    private PhaseState state = PhaseState.WAITING;
    private final PhaseCounters c = new PhaseCounters();
    private final ArrayDeque<SpawnTicket> queue = new ArrayDeque<>();
    private final Map<UUID, SpawnTicket> pending = new HashMap<>();
    private final Map<UUID, Integer> attempts = new HashMap<>();
    private double unspent;
    private long clearingSince = -1;
    private String failReason;

    public PhaseRunner(PhaseComposeRequest req, EncounterComposer composer, SpawnGateway gateway,
                       Rng rng, Settings st, long now) {
        this.req = req; this.composer = composer; this.gateway = gateway; this.rng = rng; this.st = st;
        this.gapEnd = now + st.gapTicks();
    }

    public PhaseState state() { return state; }
    public PhaseCounters counters() { return c; }
    public double unspentBudget() { return unspent; }
    public PhaseComposeRequest request() { return req; }
    public long clearingSince() { return clearingSince; }
    public String failReason() { return failReason; }

    public void tick(long now) {
        if (state == PhaseState.COMPLETED || state == PhaseState.FAILED) return;
        if (state == PhaseState.WAITING && now >= gapEnd) state = PhaseState.PREPARING;
        if (state == PhaseState.PREPARING) prepare();
        if (state == PhaseState.SPAWNING || state == PhaseState.COMBAT || state == PhaseState.CLEARING) {
            issue();
            evaluate(now);
        }
    }

    private void prepare() {
        PhasePlan plan = composer.compose(req, rng);
        unspent = plan.unspent();
        for (SpawnTicket t : plan.tickets()) queue.addLast(t);
        c.planned = c.queued = plan.tickets().size();
        state = c.planned == 0 ? PhaseState.COMPLETED : PhaseState.SPAWNING;      // P2 / P3
    }

    private void issue() {
        int n = st.spawnsPerTick();
        while (n-- > 0 && !queue.isEmpty() && c.alive() + c.pendingSpawn < st.concurrentCap()) {
            SpawnTicket t = queue.pollFirst();
            c.queued--; c.pendingSpawn++;
            pending.put(t.id(), t);
            gateway.request(t);
        }
    }

    private void evaluate(long now) {
        if (!c.resolved()) {
            if (c.queued > 0) { if (state != PhaseState.SPAWNING) state = PhaseState.SPAWNING; }   // 再投入
            else if (state == PhaseState.SPAWNING || state == PhaseState.CLEARING) state = PhaseState.COMBAT;   // P4 / P6
            return;
        }
        if (c.alive() <= 0) { state = PhaseState.COMPLETED; return; }                              // P7
        if (c.alive() <= st.residualThreshold()) {                                                  // P5
            if (state != PhaseState.CLEARING) { state = PhaseState.CLEARING; clearingSince = now; }
        } else if (state != PhaseState.COMBAT) {
            state = PhaseState.COMBAT; clearingSince = -1;                                          // P6
        }
    }

    public void onSpawnResult(SpawnResult r) {
        if (r instanceof SpawnResult.Success s) {
            if (pending.remove(s.ticketId()) == null) return;
            c.pendingSpawn--; c.spawned++;
        } else if (r instanceof SpawnResult.Retryable rt) {
            SpawnTicket t = pending.remove(rt.ticketId());
            if (t == null) return;
            c.pendingSpawn--;
            int n = attempts.merge(t.id(), 1, Integer::sum);
            if (n > st.maxRetries()) finalFail(t);
            else { c.queued++; queue.addLast(t); }
        } else if (r instanceof SpawnResult.FailedFinal ff) {
            SpawnTicket t = pending.remove(ff.ticketId());
            if (t == null) return;
            c.pendingSpawn--;
            finalFail(t);
        }
    }

    private void finalFail(SpawnTicket t) {
        c.failedFinal++;
        Optional<SpawnTicket> re = composer.reroll(t, t.cost(), req, rng);
        if (re.isPresent()) {
            c.planned++; c.queued++; queue.addLast(re.get());
            unspent += t.cost() - re.get().cost();
        } else unspent += t.cost();
    }

    public void onInvaderDied(UUID id) { c.dead++; }
    public void onInvaderLost(UUID id) { c.lost++; }
    public void registerOffspring(UUID parent, UUID child) { c.extra++; }

    /** 再読込後などに、実際の生存数との差を lost として補正する。 */
    public void reconcile(int aliveActual) { int d = c.alive() - aliveActual; if (d > 0) c.lost += d; }

    public void fail(String reason) { state = PhaseState.FAILED; failReason = reason; }
}
