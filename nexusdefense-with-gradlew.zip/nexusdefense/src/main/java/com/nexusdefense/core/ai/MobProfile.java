package com.nexusdefense.core.ai;

import java.util.EnumMap;
import java.util.Map;

/** 敵の移動能力。edges に無いエッジは使えない。値はそのエッジのコスト倍率。 */
public record MobProfile(String id, Map<EdgeType, Double> edges, double miningSpeed, double maxDigStrength,
                         double materialCost, double placeIntervalTicks) {
    public boolean allows(EdgeType e) { return edges.containsKey(e); }
    public double mult(EdgeType e) { return edges.getOrDefault(e, 1.0); }
    public double minMult() { return edges.values().stream().mapToDouble(Double::doubleValue).min().orElse(1.0); }

    public boolean canBreak(BlockInfo b) { return b.breakable() && b.strength() <= maxDigStrength; }
    /** DIGコスト = (強度×30÷採掘速度)÷5（仕様書 7.3）。 */
    public double digCost(double strength) { return (strength * 30.0 / miningSpeed) / 5.0; }

    public MobProfile withEdge(EdgeType e, double m) {
        Map<EdgeType, Double> c = new EnumMap<>(EdgeType.class);
        c.putAll(edges); c.put(e, m);
        return new MobProfile(id, c, miningSpeed, maxDigStrength, materialCost, placeIntervalTicks);
    }
}
