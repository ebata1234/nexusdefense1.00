package com.nexusdefense.core.wave;

import com.nexusdefense.core.common.SeededRng;
import java.util.*;

/** ゲームを起動せずに Wave の予算・編成を表で出す（バランス調整用）。 */
public final class WaveSimulator {
    public record Row(int wave, double budget, int mobs, double spent, Map<String, Integer> byMob) {}

    public static List<Row> run(BudgetPolicy policy, EncounterComposer composer, ThemeCatalog themes,
                                int fromWave, int toWave, int players, long seed) {
        BudgetCalculator calc = new BudgetCalculator(policy);
        SeededRng rng = new SeededRng(seed);
        List<Row> rows = new ArrayList<>();
        for (int w = fromWave; w <= toWave; w++) {
            BudgetContext ctx = new BudgetContext(w, players, 1.0, 1.0);
            double carry = 0, spent = 0; int mobs = 0;
            Map<String, Integer> by = new TreeMap<>();
            for (int p = 0; p < policy.phasesPerWave(); p++) {
                double b = calc.phaseBudget(ctx, p, carry);
                PhasePlan plan = composer.compose(new PhaseComposeRequest(w, p, b, themes.pick(w, p)), rng);
                carry = plan.unspent(); spent += plan.spent(); mobs += plan.tickets().size();
                for (SpawnTicket t : plan.tickets()) by.merge(t.mobId(), 1, Integer::sum);
            }
            rows.add(new Row(w, calc.waveBudget(ctx), mobs, spent, by));
        }
        return rows;
    }
}
