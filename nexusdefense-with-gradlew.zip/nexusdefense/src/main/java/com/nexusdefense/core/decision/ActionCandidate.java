package com.nexusdefense.core.decision;
public record ActionCandidate(ActionKind kind, ScoreBreakdown score, String target) {}
