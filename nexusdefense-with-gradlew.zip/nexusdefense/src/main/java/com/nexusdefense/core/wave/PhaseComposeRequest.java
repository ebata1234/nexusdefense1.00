package com.nexusdefense.core.wave;
public record PhaseComposeRequest(int wave, int phaseIndex, double budget, PhaseTheme theme) {}
