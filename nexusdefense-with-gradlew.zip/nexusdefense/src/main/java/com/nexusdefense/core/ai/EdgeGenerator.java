package com.nexusdefense.core.ai;

import com.nexusdefense.core.common.CellPos;
import java.util.*;

/**
 * あるセルから取れる移動エッジを列挙する。経路探索（A*）と、実行直前の再検証（revalidate）の両方で使う。
 * コストの正本はここ（設計書 4.1）。
 */
public final class EdgeGenerator {
    public static final int MAX_DROP = 4;
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private static final double INF = Double.POSITIVE_INFINITY;

    public List<PathStep> expand(WorldView w, MobProfile p, CellPos n) {
        List<PathStep> out = new ArrayList<>(16);
        for (int[] d : DIRS) horizontal(w, p, n, d[0], d[1], out);
        vertical(w, p, n, out);
        return out;
    }

    /** 実行直前の再検証。同じ到達セルへ今取れる最安のエッジを返す（無ければ empty）。 */
    public Optional<PathStep> revalidate(WorldView w, MobProfile p, PathStep s) {
        return expand(w, p, s.from()).stream().filter(e -> e.to().equals(s.to()))
            .min(Comparator.comparingDouble(PathStep::cost));
    }

    /** そのセルを通る/占有するためのコスト。通過可=0、壊せる=DIGコスト、不可=INF。 */
    private double cell(WorldView w, MobProfile p, CellPos c, List<CellPos> breaks) {
        if (!w.inBounds(c)) return INF;
        BlockInfo b = w.block(c);
        if (b.passable()) return 0;
        if (p.allows(EdgeType.DIG) && p.canBreak(b)) { breaks.add(c); return p.digCost(b.strength()); }
        return INF;
    }

    private void horizontal(WorldView w, MobProfile p, CellPos n, int dx, int dz, List<PathStep> out) {
        CellPos f = new CellPos(n.x() + dx, n.y(), n.z() + dz);
        CellPos h = f.above();
        CellPos g = f.below();

        // (1) 同じ高さ: WALK / DIG
        {
            List<CellPos> br = new ArrayList<>();
            double dig = cell(w, p, f, br) + cell(w, p, h, br);
            if (dig < INF && w.inBounds(g) && w.block(g).standable()) {
                EdgeType t = br.isEmpty() ? EdgeType.WALK : EdgeType.DIG;
                if (p.allows(t)) out.add(new PathStep(t, n, f, p.mult(t) * (1.0 + dig), br, null));
            }
        }
        // (2) 1段上: JUMP / DIG
        if (p.allows(EdgeType.JUMP)) {
            CellPos f1 = f.above(), h1 = f1.above(), head0 = n.offset(0, 2, 0);
            List<CellPos> br = new ArrayList<>();
            double dig = cell(w, p, head0, br) + cell(w, p, f1, br) + cell(w, p, h1, br);
            if (dig < INF && w.block(f).standable()) {
                EdgeType t = br.isEmpty() ? EdgeType.JUMP : EdgeType.DIG;
                if (p.allows(t)) out.add(new PathStep(t, n, f1, p.mult(t) * (1.5 + dig), br, null));
            }
        }
        // (3) DROP: 隣の列へ出て落下（最大 MAX_DROP）
        if (p.allows(EdgeType.DROP) && w.block(f).passable() && w.block(h).passable()
            && w.inBounds(g) && !w.block(g).standable()) {
            for (int k = 1; k <= MAX_DROP; k++) {
                CellPos land = new CellPos(f.x(), n.y() - k, f.z());
                if (!w.inBounds(land) || !w.block(land).passable()) break;
                CellPos floor = land.below();
                if (!w.inBounds(floor)) break;
                if (w.block(floor).standable()) {
                    double fall = 1.0 + 0.5 * k + Math.max(0, k - 3) * 2.0;
                    out.add(new PathStep(EdgeType.DROP, n, land, p.mult(EdgeType.DROP) * fall, List.of(), null));
                    break;
                }
                if (w.block(floor).kind() == BlockKind.HAZARD) break;
            }
        }
        // (4) BRIDGE: 床が無い隣の列へ、足場を置いて渡る
        if (p.allows(EdgeType.BRIDGE) && w.block(f).passable() && w.block(h).passable()
            && w.inBounds(g) && w.block(g).kind() == BlockKind.AIR) {
            double c = p.placeIntervalTicks() / 5.0 + p.materialCost();
            out.add(new PathStep(EdgeType.BRIDGE, n, f, p.mult(EdgeType.BRIDGE) * c, List.of(), g));
        }
    }

    private void vertical(WorldView w, MobProfile p, CellPos n, List<PathStep> out) {
        CellPos up = n.above(), up2 = up.above();
        if (!w.inBounds(up2)) return;

        // 既存のはしごを登る
        if (p.allows(EdgeType.CLIMB) && w.block(up).kind() == BlockKind.LADDER && w.block(up2).passable())
            out.add(new PathStep(EdgeType.CLIMB, n, up, p.mult(EdgeType.CLIMB) * 1.2, List.of(), null));

        // はしごを設置して登る（支えとなる壁が必要）
        if (p.allows(EdgeType.LADDER) && w.block(up).kind() == BlockKind.AIR && w.block(up2).passable()
            && hasSupport(w, up))
            out.add(new PathStep(EdgeType.LADDER, n, up, p.mult(EdgeType.LADDER) * (2.0 + p.materialCost()), List.of(), up));

        // 足元にブロックを積んで登る（塔）
        if (p.allows(EdgeType.TOWER) && w.block(n).kind() == BlockKind.AIR
            && w.block(up).passable() && w.block(up2).passable())
            out.add(new PathStep(EdgeType.TOWER, n, up, p.mult(EdgeType.TOWER) * (3.0 + p.materialCost()), List.of(), n));
    }

    private boolean hasSupport(WorldView w, CellPos c) {
        for (int[] d : DIRS) {
            CellPos s = c.offset(d[0], 0, d[1]);
            if (w.inBounds(s) && w.block(s).standable()) return true;
        }
        return false;
    }
}
