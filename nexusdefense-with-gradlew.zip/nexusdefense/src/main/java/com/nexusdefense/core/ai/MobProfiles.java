package com.nexusdefense.core.ai;

import java.util.EnumMap;
import java.util.Map;

public final class MobProfiles {
    private MobProfiles() {}

    private static Map<EdgeType, Double> edges(EdgeType... es) {
        Map<EdgeType, Double> m = new EnumMap<>(EdgeType.class);
        for (EdgeType e : es) m.put(e, 1.0);
        return m;
    }

    /** 低速で採掘する（弱いブロックのみ）。 */
    public static final MobProfile ZOMBIE = new MobProfile("zombie",
        edges(EdgeType.WALK, EdgeType.JUMP, EdgeType.DROP, EdgeType.CLIMB, EdgeType.DIG), 1.0, 2.5, 0.5, 10);
    /** 高速採掘。 */
    public static final MobProfile MINER = new MobProfile("miner",
        edges(EdgeType.WALK, EdgeType.JUMP, EdgeType.DROP, EdgeType.CLIMB, EdgeType.DIG), 3.0, 8.0, 0.5, 10);
    /** 橋・はしご・塔が使える。 */
    public static final MobProfile ENGINEER = new MobProfile("engineer",
        edges(EdgeType.WALK, EdgeType.JUMP, EdgeType.DROP, EdgeType.CLIMB, EdgeType.DIG,
              EdgeType.BRIDGE, EdgeType.LADDER, EdgeType.TOWER), 3.0, 5.0, 0.5, 10);

    public static MobProfile byId(String id) {
        return switch (id) { case "zombie_miner" -> MINER; case "engineer" -> ENGINEER; default -> ZOMBIE; };
    }
}
