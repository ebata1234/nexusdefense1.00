package com.nexusdefense.core.wave;

import com.nexusdefense.core.common.Rng;
import java.util.UUID;

/** Wave（複数Phase）の進行管理。Phaseが全て完了したら waveCleared() が true になる。 */
public final class WaveController {
    public interface Listener {
        void onPhaseStarted(int wave, int phaseIndex, PhaseTheme theme, double budget);
    }

    private final BudgetPolicy policy;
    private final BudgetCalculator calc;
    private final EncounterComposer composer;
    private final ThemeCatalog themes;
    private final PhaseRunner.SpawnGateway gateway;
    private final Rng rng;
    private final PhaseRunner.Settings settings;
    private final Listener listener;

    private int wave, phaseIndex;
    private BudgetContext ctx;
    private PhaseRunner current;
    private boolean cleared;
    private double carry;
    private int firstGapTicks = 40;

    public WaveController(BudgetPolicy policy, EncounterComposer composer, ThemeCatalog themes,
                          PhaseRunner.SpawnGateway gateway, Rng rng, PhaseRunner.Settings settings, Listener listener) {
        this.policy = policy; this.calc = new BudgetCalculator(policy); this.composer = composer;
        this.themes = themes; this.gateway = gateway; this.rng = rng; this.settings = settings; this.listener = listener;
    }

    public void setFirstGapTicks(int t) { this.firstGapTicks = t; }

    public void startWave(int wave, int players, double difficulty, long now) {
        this.wave = wave; this.phaseIndex = 0; this.carry = 0; this.cleared = false;
        this.ctx = new BudgetContext(wave, players, difficulty, 1.0);
        startPhase(now, firstGapTicks);
    }

    private void startPhase(long now, int gap) {
        double budget = calc.phaseBudget(ctx, phaseIndex, carry);
        PhaseTheme theme = themes.pick(wave, phaseIndex);
        PhaseRunner.Settings s = new PhaseRunner.Settings(gap, settings.residualThreshold(),
            settings.spawnsPerTick(), settings.concurrentCap(), settings.maxRetries());
        current = new PhaseRunner(new PhaseComposeRequest(wave, phaseIndex, budget, theme), composer, gateway, rng, s, now);
        if (listener != null) listener.onPhaseStarted(wave, phaseIndex, theme, budget);
    }

    public void tick(long now) {
        if (current == null || cleared) return;
        current.tick(now);
        PhaseState st = current.state();
        if (st == PhaseState.COMPLETED || st == PhaseState.FAILED) {
            carry = current.unspentBudget();
            phaseIndex++;
            if (phaseIndex >= policy.phasesPerWave()) { cleared = true; current = null; }
            else startPhase(now, settings.gapTicks());
        }
    }

    public boolean waveCleared() { return cleared; }
    public int wave() { return wave; }
    public int phaseIndex() { return phaseIndex; }
    public PhaseRunner current() { return current; }
    public int alive() { return current == null ? 0 : current.counters().alive(); }

    public void onSpawnResult(SpawnResult r) { if (current != null) current.onSpawnResult(r); }
    public void onInvaderDied(UUID id) { if (current != null) current.onInvaderDied(id); }
    public void onInvaderLost(UUID id) { if (current != null) current.onInvaderLost(id); }
    public void registerOffspring(UUID parent, UUID child) { if (current != null) current.registerOffspring(parent, child); }
}
