package com.nexusdefense.core.wave;

import java.util.*;

public final class ThemeCatalog {
    public record ThemeDef(PhaseTheme theme, Map<Role, Double> roleWeights, Map<Role, Double> roleCapFraction) {
        public double weight(Role r) { return roleWeights.getOrDefault(r, 0.0); }
        public double capFraction(Role r) { return roleCapFraction.getOrDefault(r, 1.0); }
    }

    private final Map<PhaseTheme, ThemeDef> defs = new EnumMap<>(PhaseTheme.class);

    public ThemeCatalog() {
        Map<Role, Double> caps = Map.of(Role.ENGINEER, 0.2, Role.MINER, 0.5);
        defs.put(PhaseTheme.SWARM, new ThemeDef(PhaseTheme.SWARM, Map.of(Role.MELEE, 1.0), caps));
        defs.put(PhaseTheme.MELEE, new ThemeDef(PhaseTheme.MELEE, Map.of(Role.MELEE, 1.0, Role.MINER, 0.3), caps));
        defs.put(PhaseTheme.SIEGE, new ThemeDef(PhaseTheme.SIEGE,
            Map.of(Role.MINER, 1.0, Role.ENGINEER, 0.8, Role.MELEE, 0.4), caps));
        defs.put(PhaseTheme.MIXED, new ThemeDef(PhaseTheme.MIXED,
            Map.of(Role.MELEE, 1.0, Role.MINER, 0.6, Role.ENGINEER, 0.5), caps));
    }

    public ThemeDef get(PhaseTheme t) { return defs.get(t); }

    /** Phase番号に応じたテーマ（試作: 0=SWARM, 1=MELEE, 2=SIEGE, 3=MIXED）。 */
    public PhaseTheme pick(int wave, int phaseIndex) {
        return switch (phaseIndex) { case 0 -> PhaseTheme.SWARM; case 1 -> PhaseTheme.MELEE;
            case 2 -> PhaseTheme.SIEGE; default -> PhaseTheme.MIXED; };
    }
}
