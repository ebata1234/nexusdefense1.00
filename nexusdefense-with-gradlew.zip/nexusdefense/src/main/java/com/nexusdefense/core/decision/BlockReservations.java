package com.nexusdefense.core.decision;

import com.nexusdefense.core.common.CellPos;
import java.util.*;

/** 建築予約（TTL付き）。複数のEngineerが同じセルを同時に設置しないための排他。 */
public final class BlockReservations {
    public record Token(UUID id, UUID owner, Set<CellPos> cells, long expiresAt) {}
    private final Map<UUID, Token> tokens = new HashMap<>();

    public Optional<Token> tryReserve(UUID owner, Set<CellPos> cells, long now, int ttl) {
        expire(now);
        for (Token t : tokens.values())
            if (!t.owner().equals(owner) && !Collections.disjoint(t.cells(), cells)) return Optional.empty();
        Token n = new Token(UUID.randomUUID(), owner, Set.copyOf(cells), now + ttl);
        tokens.put(n.id(), n);
        return Optional.of(n);
    }
    public boolean isReservedByOther(UUID self, CellPos c, long now) {
        expire(now);
        return tokens.values().stream().anyMatch(t -> !t.owner().equals(self) && t.cells().contains(c));
    }
    public void release(Token t) { tokens.remove(t.id()); }
    public void releaseAll(UUID owner) { tokens.values().removeIf(t -> t.owner().equals(owner)); }
    public void expire(long now) { tokens.values().removeIf(t -> t.expiresAt() <= now); }
    public int size() { return tokens.size(); }
}
