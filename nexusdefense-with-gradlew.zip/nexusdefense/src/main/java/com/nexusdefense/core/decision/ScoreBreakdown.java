package com.nexusdefense.core.decision;

public record ScoreBreakdown(double base, double role, double pathGain, double goalGain,
                             double risk, double resource, double cooldown) {
    public double total() { return base + role + pathGain + goalGain - risk - resource - cooldown; }
    public String explain() {
        return String.format("base=%.1f role=%+.1f path=%+.1f goal=%+.1f risk=-%.1f res=-%.1f cd=-%.1f => %.1f",
            base, role, pathGain, goalGain, risk, resource, cooldown, total());
    }
}
