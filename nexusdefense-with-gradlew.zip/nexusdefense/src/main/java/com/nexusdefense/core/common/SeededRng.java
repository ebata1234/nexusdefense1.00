package com.nexusdefense.core.common;

import java.util.SplittableRandom;

public final class SeededRng implements Rng {
    private final SplittableRandom r;
    public SeededRng(long seed) { this.r = new SplittableRandom(seed); }
    @Override public double nextDouble() { return r.nextDouble(); }
    @Override public int nextInt(int bound) { return r.nextInt(bound); }
    @Override public long nextLong() { return r.nextLong(); }
}
