package com.nexusdefense.core.wave;

public final class BudgetCalculator {
    private final BudgetPolicy p;
    public BudgetCalculator(BudgetPolicy p) { this.p = p; }

    public double waveBudget(BudgetContext c) {
        int players = Math.min(Math.max(c.playerCount(), 1), p.maxScaledPlayers());
        double n = c.wave();
        double raw = p.base() + p.linear() * n + p.quadratic() * n * n;
        return raw * c.difficulty() * c.catalystMultiplier() * (1.0 + p.perExtraPlayer() * (players - 1));
    }

    /** Phase予算 = Wave予算×重み + 前Phaseの繰越（Phase予算の carryOverCapRatio まで）。 */
    public double phaseBudget(BudgetContext c, int phaseIndex, double carryOver) {
        double b = waveBudget(c) * p.phaseWeights()[phaseIndex];
        return b + Math.min(Math.max(carryOver, 0), b * p.carryOverCapRatio());
    }
}
