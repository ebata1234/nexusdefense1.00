package com.nexusdefense.core.decision;

import com.nexusdefense.core.wave.Role;

/** 行動評価式（設計書 3.3）。 ActionScore = base + role + pathGain + goalGain − risk − resource − cooldown */
public final class ActionScorer {
    private ActionScorer() {}

    public static double base(ActionKind k) {
        return switch (k) {
            case ATTACK_NEXUS -> 80; case SIEGE_SHOOT -> 70; case DETONATE -> 65; case FOLLOW_PLAN -> 40;
            case DIG_BLOCKER, BUILD_CROSSING -> 35; case ATTACK_PLAYER -> 30; case ATTACK_ENTITY -> 20;
            case REPOSITION, HOLD_BACK -> 10;
        };
    }

    public static double roleBonus(Role r, ActionKind k) {
        return switch (r) {
            case MINER -> k == ActionKind.DIG_BLOCKER ? 20 : 0;
            case ENGINEER -> switch (k) { case BUILD_CROSSING -> 25; case DIG_BLOCKER -> 10; case ATTACK_PLAYER -> -15; default -> 0; };
            case MELEE -> switch (k) { case ATTACK_PLAYER -> 5; case DIG_BLOCKER -> -5; default -> 0; };
            case RANGED -> k == ActionKind.SIEGE_SHOOT ? 15 : 0;
            case SIEGE -> k == ActionKind.DETONATE ? 20 : 0;
            case BURROWER -> k == ActionKind.FOLLOW_PLAN ? 20 : 0;
            default -> 0;
        };
    }

    /** pathGain = 40 × clamp((C_now − C_after) ÷ C_now, 0, 1) */
    public static double pathGain(double cNow, double cAfter) {
        if (cNow <= 0) return 0;
        return 40.0 * Math.max(0, Math.min(1, (cNow - cAfter) / cNow));
    }

    public static ScoreBreakdown score(ActionKind k, Role r, double cNow, double cAfter, double goalGain,
                                       double risk, double resource, double cooldown) {
        return new ScoreBreakdown(base(k), roleBonus(r, k), pathGain(cNow, cAfter), goalGain,
            Math.min(60, risk), resource, cooldown);
    }
}
