package com.nexusdefense.core.wave;

import java.util.UUID;

public record SpawnTicket(UUID id, String mobId, Role role, double cost) {}
