package com.nexusdefense.core.wave;
public enum PhaseState { WAITING, PREPARING, SPAWNING, COMBAT, CLEARING, COMPLETED, FAILED }
