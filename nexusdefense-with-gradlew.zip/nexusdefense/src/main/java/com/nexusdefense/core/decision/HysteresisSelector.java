package com.nexusdefense.core.decision;

import java.util.Comparator;
import java.util.List;

/** 行動の振動防止: 新候補が「現在×1.25」かつ「現在+5」を超え、20tick以上継続したときだけ切替。 */
public final class HysteresisSelector {
    private final double ratio, minMargin;
    private final int minHoldTicks;

    public HysteresisSelector(double ratio, double minMargin, int minHoldTicks) {
        this.ratio = ratio; this.minMargin = minMargin; this.minHoldTicks = minHoldTicks;
    }
    public static HysteresisSelector defaults() { return new HysteresisSelector(1.25, 5.0, 20); }

    public Selection select(ActiveAction cur, List<ActionCandidate> cs, long tick) {
        if (cs.isEmpty()) return Selection.keep();
        ActionCandidate best = cs.stream().max(Comparator.comparingDouble(c -> c.score().total())).get();
        if (cur == null || cur.invalidated()) return Selection.switchTo(best);
        if (best.kind() == cur.kind()) return Selection.keep();
        double curScore = cur.latestScore();
        boolean held = tick - cur.startedTick() >= minHoldTicks;
        boolean better = best.score().total() >= Math.max(curScore * ratio, curScore + minMargin);
        return (held && better) ? Selection.switchTo(best) : Selection.keep();
    }
}
