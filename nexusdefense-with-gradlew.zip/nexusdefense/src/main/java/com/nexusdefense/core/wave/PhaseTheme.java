package com.nexusdefense.core.wave;
public enum PhaseTheme { SWARM, MELEE, SIEGE, MIXED }
