package com.nexusdefense.core.nexus;

/** Nexusの集約ルート。状態の変更は NexusStateMachine 経由のみ（setterは package-private）。 */
public final class NexusData {
    private NexusState state = NexusState.INACTIVE;
    private NexusState resumeTo = NexusState.ACTIVE;
    private final double maxHealth;
    private double health;
    private int wave = 1;
    private int maxWaveReached = 0;
    private int totalKills = 0;

    public NexusData(double maxHealth) {
        if (maxHealth <= 0) throw new IllegalArgumentException("maxHealth must be positive");
        this.maxHealth = maxHealth;
        this.health = maxHealth;
    }

    public NexusState state() { return state; }
    public NexusState resumeTo() { return resumeTo; }
    public double health() { return health; }
    public double maxHealth() { return maxHealth; }
    public int wave() { return wave; }
    public int maxWaveReached() { return maxWaveReached; }
    public int totalKills() { return totalKills; }
    public void addKill() { totalKills++; }

    /** 保存データからの復元用（ワールド読込時のみ使用）。 */
    public void restore(NexusState state, NexusState resumeTo, double health, int wave, int maxWaveReached, int kills) {
        this.state = state;
        this.resumeTo = resumeTo;
        this.health = Math.max(0, Math.min(maxHealth, health));
        this.wave = Math.max(1, wave);
        this.maxWaveReached = Math.max(0, maxWaveReached);
        this.totalKills = Math.max(0, kills);
    }

    void setState(NexusState s) { this.state = s; }
    void setResumeTo(NexusState s) { this.resumeTo = s; }
    void resetProgress() { wave = 1; health = maxHealth; totalKills = 0; }
    void noteWaveCleared(int w) { maxWaveReached = Math.max(maxWaveReached, w); }
    void advanceWave() { wave++; }
    void applyDamage(double amount) { health = Math.max(0, health - amount); }
}
