package com.nexusdefense.core.wave;

import java.util.UUID;

public sealed interface SpawnResult {
    record Success(UUID ticketId, UUID invader) implements SpawnResult {}
    record Retryable(UUID ticketId, String reason) implements SpawnResult {}
    record FailedFinal(UUID ticketId, String reason) implements SpawnResult {}
}
