package com.nexusdefense.core.decision;

public final class ActiveAction {
    private final ActionKind kind;
    private final long startedTick;
    private double latestScore;
    private boolean invalidated;

    public ActiveAction(ActionKind kind, long startedTick, double score) {
        this.kind = kind; this.startedTick = startedTick; this.latestScore = score;
    }
    public ActionKind kind() { return kind; }
    public long startedTick() { return startedTick; }
    public double latestScore() { return latestScore; }
    public void updateScore(double s) { latestScore = s; }
    public boolean invalidated() { return invalidated; }
    public void invalidate() { invalidated = true; }
}
