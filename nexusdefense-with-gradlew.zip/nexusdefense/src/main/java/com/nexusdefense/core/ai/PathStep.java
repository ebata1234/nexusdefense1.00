package com.nexusdefense.core.ai;

import com.nexusdefense.core.common.CellPos;
import java.util.List;

/** 経路の1歩。breaks=壊すセル、place=設置するセル（BRIDGE:床 / LADDER:はしご / TOWER:現在セル）。 */
public record PathStep(EdgeType edge, CellPos from, CellPos to, double cost, List<CellPos> breaks, CellPos place) {}
