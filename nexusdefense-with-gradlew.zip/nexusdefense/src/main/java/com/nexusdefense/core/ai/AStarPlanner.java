package com.nexusdefense.core.ai;

import com.nexusdefense.core.common.CellPos;
import java.util.*;

/**
 * エッジ付きA*。ヒューリスティクス = 最小エッジ倍率 × max(0, 水平チェビシェフ距離 − reach)。
 * 水平1歩のエッジは必ずコスト≥1×最小倍率なので許容的（過大評価しない）。
 */
public final class AStarPlanner {
    private final EdgeGenerator edges = new EdgeGenerator();

    private record Q(CellPos pos, double g, double f, long seq) {}

    public PathPlan plan(WorldView w, MobProfile p, CellPos start, CellPos goal, int reach, int nodeLimit, int radius) {
        return plan(w, p, start, goal, reach, nodeLimit, radius, true);
    }

    public PathPlan plan(WorldView w, MobProfile p, CellPos start, CellPos goal, int reach,
                         int nodeLimit, int radius, boolean useHeuristic) {
        double hScale = useHeuristic ? p.minMult() : 0.0;
        PriorityQueue<Q> open = new PriorityQueue<>(Comparator.<Q>comparingDouble(Q::f).thenComparingLong(Q::seq));
        Map<CellPos, Double> best = new HashMap<>();
        Map<CellPos, PathStep> parent = new HashMap<>();
        long seq = 0;
        best.put(start, 0.0);
        open.add(new Q(start, 0, h(hScale, start, goal, reach), seq++));

        CellPos bestNode = start;
        double bestH = h(hScale, start, goal, reach), bestG = 0;
        int expanded = 0;

        while (!open.isEmpty() && expanded < nodeLimit) {
            Q cur = open.poll();
            if (cur.g() > best.get(cur.pos())) continue;                 // 古いエントリ
            if (goal.chebyshev(cur.pos()) <= reach && !cur.pos().equals(goal))
                return build(cur.pos(), start, parent, false, cur.g(), expanded);
            expanded++;
            double hc = h(hScale, cur.pos(), goal, reach);
            if (hc < bestH || (hc == bestH && cur.g() < bestG)) { bestNode = cur.pos(); bestH = hc; bestG = cur.g(); }
            for (PathStep e : edges.expand(w, p, cur.pos())) {
                if (e.to().chebyshev(start) > radius) continue;
                double ng = cur.g() + e.cost();
                Double old = best.get(e.to());
                if (old == null || ng < old) {
                    best.put(e.to(), ng);
                    parent.put(e.to(), e);
                    open.add(new Q(e.to(), ng, ng + h(hScale, e.to(), goal, reach), seq++));
                }
            }
        }
        return build(bestNode, start, parent, true, bestG, expanded);
    }

    private static double h(double scale, CellPos c, CellPos goal, int reach) {
        int d = Math.max(Math.abs(c.x() - goal.x()), Math.abs(c.z() - goal.z()));
        return scale * Math.max(0, d - reach);
    }

    private PathPlan build(CellPos end, CellPos start, Map<CellPos, PathStep> parent, boolean partial, double cost, int expanded) {
        LinkedList<PathStep> steps = new LinkedList<>();
        CellPos c = end;
        while (!c.equals(start)) {
            PathStep s = parent.get(c);
            if (s == null) break;
            steps.addFirst(s);
            c = s.from();
        }
        return new PathPlan(List.copyOf(steps), partial, cost, expanded);
    }
}
