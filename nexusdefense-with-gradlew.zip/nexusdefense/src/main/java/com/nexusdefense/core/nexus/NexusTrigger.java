package com.nexusdefense.core.nexus;

public sealed interface NexusTrigger {
    record StartRequested() implements NexusTrigger {}
    record CatalystValidated() implements NexusTrigger {}
    record CatalystRejected() implements NexusTrigger {}
    record WaveCleared(int wave) implements NexusTrigger {}
    record TransitionElapsed() implements NexusTrigger {}
    record PauseRequested() implements NexusTrigger {}
    record ResumeRequested() implements NexusTrigger {}
    record StopRequested() implements NexusTrigger {}
    record HealthDepleted() implements NexusTrigger {}
    record ResetRequested() implements NexusTrigger {}
    record CleanupFinished() implements NexusTrigger {}
    record IntegrityViolation(String detail) implements NexusTrigger {}
}
