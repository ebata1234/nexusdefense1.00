package com.nexusdefense.core.nexus;

import static com.nexusdefense.core.nexus.NexusState.*;

/**
 * 詳細設計書 1.3 の遷移表 T1〜T12 の実装。
 * 不正な遷移は accepted=false で拒否する（DEFEATED→ACTIVE 等は存在しない）。
 */
public final class NexusStateMachine {

    public TransitionResult fire(NexusData d, NexusTrigger t) {
        NexusState from = d.state();
        NexusState to = null;

        if (t instanceof NexusTrigger.StartRequested) {                      // T1
            if (from == INACTIVE) to = PREPARING;
        } else if (t instanceof NexusTrigger.CatalystValidated) {           // T2
            if (from == PREPARING) { d.resetProgress(); to = ACTIVE; }
        } else if (t instanceof NexusTrigger.CatalystRejected) {            // T3
            if (from == PREPARING) to = INACTIVE;
        } else if (t instanceof NexusTrigger.WaveCleared wc) {              // T4
            if (from == ACTIVE) { d.noteWaveCleared(wc.wave()); to = WAVE_TRANSITION; }
        } else if (t instanceof NexusTrigger.TransitionElapsed) {           // T5
            if (from == WAVE_TRANSITION) { d.advanceWave(); to = ACTIVE; }
        } else if (t instanceof NexusTrigger.PauseRequested) {              // T6
            if (from == ACTIVE || from == WAVE_TRANSITION) { d.setResumeTo(from); to = PAUSED; }
        } else if (t instanceof NexusTrigger.ResumeRequested) {             // T7
            if (from == PAUSED) to = d.resumeTo();
        } else if (t instanceof NexusTrigger.StopRequested) {               // T8
            if (from == ACTIVE || from == WAVE_TRANSITION || from == PAUSED) to = STOPPED;
        } else if (t instanceof NexusTrigger.CleanupFinished) {             // T9
            if (from == STOPPED || from == ERROR || from == DEFEATED) to = INACTIVE;
        } else if (t instanceof NexusTrigger.HealthDepleted) {              // T10
            if (from == ACTIVE) to = DEFEATED;
        } else if (t instanceof NexusTrigger.ResetRequested) {              // T11
            if (from == DEFEATED) to = INACTIVE;
        } else if (t instanceof NexusTrigger.IntegrityViolation) {          // T12
            if (from != ERROR) to = ERROR;
        }

        if (to == null) return TransitionResult.rejected(from, t.getClass().getSimpleName());
        d.setState(to);
        return TransitionResult.ok(from, to);
    }

    public boolean canFire(NexusData d, NexusTrigger t) {
        // 副作用なしで判定するため、複製に対して発火する
        NexusData copy = new NexusData(d.maxHealth());
        copy.restore(d.state(), d.resumeTo(), d.health(), d.wave(), d.maxWaveReached(), d.totalKills());
        return fire(copy, t).accepted();
    }

    /** damageNexus: ACTIVE・正値のみ受理。HPが0になったら DEFEATED へ遷移。 */
    public DamageResult damage(NexusData d, double amount) {
        if (!d.state().acceptsDamage())
            return new DamageResult(DamageResult.Outcome.REJECTED_STATE, 0, d.health(), false);
        if (!(amount > 0) || Double.isNaN(amount) || Double.isInfinite(amount))
            return new DamageResult(DamageResult.Outcome.REJECTED_INVALID, 0, d.health(), false);
        double before = d.health();
        d.applyDamage(amount);
        boolean lethal = d.health() <= 0;
        if (lethal) fire(d, new NexusTrigger.HealthDepleted());
        return new DamageResult(DamageResult.Outcome.APPLIED, before - d.health(), d.health(), lethal);
    }
}
