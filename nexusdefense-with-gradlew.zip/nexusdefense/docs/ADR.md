# 決定事項（ADR）— 試作で採用した判断

| # | 論点 | 決定 | 理由 / 備考 |
|---|---|---|---|
| 1 | Mobのエンティティ方針 | 独自EntityType。13種をそれぞれ登録し、クラスは `InvaderEntity`（Zombie派生）を共用 | ID を VisualPack の geo/animation/texture/lang と一致でき、当たり判定も型ごとに設定できる |
| 2 | A*の実行方式 | 試作は同期実行（1tickあたり6件・1500ノード上限）。時間分割A*は未実装 | 先に実測する。設計書 R1 |
| 3 | チャンク/プレイヤー不在 | 未ロードは通行不可。Nexusに紐付くのに追跡されていない個体は消す | 自動PAUSEは未実装 |
| 4 | PAUSEDの意味 | coreでは実装済み（無敵・復帰先を記録）。ゲーム内の操作は未提供 | |
| 5 | 領域保護MODとの連携 | 未実装 | 設計書 R10 |
| 6 | Mobコスト | Zombie=1 / Miner=3 / Engineer=6 | WaveSimulator で調整 |
| 7 | 権限 | 試作は誰でも操作可 | 設計書 R11 |
| 8 | 状態の正本 | 試作は BlockEntity NBT。SavedData への移行は未実施 | 本設計との差分 |
| 9 | DIGの倍率 | 全エッジ倍率1.0。速度はコスト式のみで表現 | 二重計上の回避。設計書 R6 |
| 10 | 素材導入 | `resourcepack/assets/nexusdefense` のみMODへ。`assets/minecraft` の上書きは入れない | 他MODとの競合回避 |
| 11 | ブロックの向き | 向き固定（北向き）。FACINGプロパティは追加しない | blockstate JSON が単一variantのため |
