# Nexus Defense — 防衛MOD 試作 v0.1.0

Minecraft 1.20.1 / Forge 47.x / Java 17 / GeckoLib 4.x

## 何ができるか
- Nexus Core を置き、**ニュートラルな触媒(Nexus Catalyst)を持って右クリック**すると Wave が始まる。
- 敵（Zombie / Zombie Miner / Engineer）が Wave 予算に従って湧き、**経路探索で Nexus を目指す**。
  掘る(DIG)・橋(BRIDGE)・はしご(LADDER)・塔(TOWER)・落ちる・登る を、コスト比較で自動選択して実行する。
- Nexus の HP が 0 になると陥落。素手でShift+右クリックで停止。素手で右クリックで状態表示。
- **VisualPack v2 のブロック11種・アイテム14種・Mob 13種(Pit Colossus含む)を登録**。クリエイティブタブ「Nexus Defense」で全て確認できる（通常アイテムに効果は付けていない）。

## ビルドと起動
```
./gradlew runClient          # ゲーム内確認
./gradlew build              # build/libs/nexusdefense-0.1.0.jar
sh scripts/run-core-tests.sh # Forge不要: core層の検証(純Java・JDK17+)
python3 scripts/audit_assets.py   # Forge不要: 素材配線の監査(要Pillow)
```
Gradle Wrapper(`gradlew`)は同梱していない。Forge 1.20.1 MDK から `gradlew` / `gradle/` をコピーするか、`gradle wrapper` で生成する。
GeckoLib のバージョンが解決できない場合は `gradle.properties` の `geckolib_version` だけ変更する。

## ゲーム内での確認手順
1. クリエイティブタブ **Nexus Defense** を開く → ブロック11種・アイテム14種・スポーンエッグ13種が並ぶ。
2. Nexus Core を設置（正面=北面に触媒スロット。結晶はアニメーション）。他のブロックも設置して見た目を確認。
3. 各スポーンエッグで Mob を出し、テクスチャ・モデルを確認（`/summon nexusdefense:pit_colossus` も可）。
   スポーンエッグで出した個体は Nexus に紐付かないためプレイヤーを攻撃しない。
4. `/give @p nexusdefense:nexus_catalyst 4` → Nexus Core を右クリックで侵略開始。

## 構成
```
core/      純Java（net.minecraft 非依存・ArchUnit相当の検査あり）: nexus / wave / ai / decision
game/      Forge: registry, block, blockentity, entity(InvaderEntity, InvaderBrainGoal), service(アダプター)
client/    GeckoLibレンダラー（Dedicated Serverでは読み込まれない）
resources  assets/nexusdefense: VisualPack v2 + Mob(geo/animation/texture) + Pit Colossus / data: 戦利品表・レシピ
```

## 検証の状況（正直な記録）
| 対象 | 状況 |
|---|---|
| core層（Nexus状態機械・Wave予算・編成・Phase進行・行動評価・経路探索・実行シミュレーション） | **117件すべて合格**（`docs/verification/core_tests.txt`） |
| 素材配線（登録ID↔blockstate/model/texture/lang/GeckoLib 3点セット） | **2032項目すべてOK**（`docs/verification/asset_audit.txt`） |
| game/client層（Forge連携） | **未コンパイル・未実機確認**。Forge/GeckoLib/ネットワークの無い環境で作成。構文エラーが無いことのみ確認。シンボル名・APIの差異は初回ビルドで出る可能性がある |
| ゲーム内の見た目・当たり判定・アニメーション | **未確認** |

## 既知の問題・限界
- **旧Mob 12種のジオメトリ**: geo の cube 座標が不整合（Zombie: 脚 y=0〜12 に対し、胴 -20〜-8 / 頭 -8〜0）。GeckoLibの解釈では胴・頭が地面の下になり、**正しく表示されない可能性が高い**。テクスチャ寸法・アニメーション名の整合は確認済み。Blockbench で確認・修正が必要。Pit Colossus のジオメトリは整合（高さ0〜5.88）で、アニメーション未同梱のため静止表示。
- ブロックの当たり判定は全て通常の立方体（VoxelShapeは未定義）。罠・塔・ビーコンに効果は無い。
- 経路探索は同期実行。水は危険扱い。領域保護MODとの連携なし。状態はBlockEntity保存（SavedDataではない）。

## GitHub でjarをビルドする
1. このプロジェクトをGitHubリポジトリにアップロードする（`.github/workflows/build.yml` を含める）。
2. **Actions** タブ → `Build Nexus Defense` → 緑のチェックが付いたら、実行結果ページ下部の **Artifacts → nexusdefense-jar** を開く。
3. 手動実行は Actions → Build Nexus Defense → **Run workflow**。
4. `v0.1.0` のようなタグを push すると、Releases にjarが自動で添付される。
Gradle Wrapper が無くてもCIは動く（Gradle 8.8 をCI側で用意する）。
