@echo off
rem ======================================================================
rem  Nexus Defense - hardened Gradle launcher (Windows)
rem
rem  Security design:
rem   * No PowerShell, no ExecutionPolicy bypass.
rem   * Uses only Windows built-in tools by FULL path (System32):
rem       curl.exe (download), certutil.exe (SHA-256), tar.exe (unzip)
rem   * HTTPS only (TLS 1.2+), redirects limited.
rem   * Gradle zip is verified against a PINNED SHA-256 before extraction.
rem     Source: https://gradle.org/release-checksums/
rem   * Installs only under LOCALAPPDATA\NexusDefense (per-user, no admin).
rem   * Never modifies system settings, registry, PATH or JAVA_HOME.
rem   * Requires Java 17 (needed by Minecraft 1.20.1 / Forge 47).
rem   * ASCII only (avoids code page problems on Japanese Windows).
rem
rem  Usage:
rem    gradlew.bat            : runs build, jar is created in build\libs
rem    gradlew.bat TASKNAME   : runs the given Gradle tasks
rem ======================================================================
setlocal EnableExtensions DisableDelayedExpansion

set "RC=0"
set "PAUSE_AT_END="
if "%~1"=="" set "PAUSE_AT_END=1"

set "GRADLE_VERSION=8.8"
set "GRADLE_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"
set "GRADLE_SHA256=a4b4158601f8636cdeeab09bd76afb640030bb5b144aafe261a5e8af027dc612"

set "SYS32=%SystemRoot%\System32"
set "BASE_DIR=%LOCALAPPDATA%\NexusDefense"
set "GRADLE_HOME=%BASE_DIR%\gradle-%GRADLE_VERSION%"
set "GRADLE_BAT=%GRADLE_HOME%\bin\gradle.bat"
set "VERIFIED_MARK=%GRADLE_HOME%\.sha256-verified"

rem Always run from the project folder (where this file lives).
cd /d "%~dp0" || goto :fail_cd

if not exist "build.gradle" goto :fail_no_project

rem ---------------------------------------------------------------
rem 1. Find Java 17
rem ---------------------------------------------------------------
set "JAVA_EXE="
rem (a) JAVA_HOME if valid
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
rem (b) java.exe on PATH. The $PATH: form never searches the current folder,
rem     so a java.exe planted in the project folder is not picked up.
if not defined JAVA_EXE (
    for /f "delims=" %%j in ('where $PATH:java.exe 2^>nul') do (
        if not defined JAVA_EXE set "JAVA_EXE=%%j"
    )
)
rem (c) standard JDK 17 install folders. JAVA_HOME is set for this run only.
if not defined JAVA_EXE (
    for %%p in ("%ProgramFiles%\Eclipse Adoptium" "%ProgramFiles%\Java" "%ProgramFiles%\Microsoft" "%ProgramFiles%\Zulu" "%ProgramFiles%\Amazon Corretto") do (
        for /d %%d in ("%%~p\*-17*" "%%~p\*jdk17*") do (
            if not defined JAVA_EXE if exist "%%~d\bin\java.exe" set "JAVA_HOME=%%~d" & set "JAVA_EXE=%%~d\bin\java.exe"
        )
    )
)
if not defined JAVA_EXE goto :fail_java_missing

rem Always give Gradle an explicit JAVA_HOME (parent of bin) so that it never
rem looks up "java" by name, which could resolve to the current folder.
for %%i in ("%JAVA_EXE%") do set "JAVA_BIN=%%~dpi"
for %%i in ("%JAVA_BIN%..") do set "JAVA_HOME=%%~fi"
set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
if not exist "%JAVA_EXE%" goto :fail_java_missing

set "JAVA_VER="
for /f "tokens=3" %%v in ('"%JAVA_EXE%" -version 2^>^&1') do (
    if not defined JAVA_VER set "JAVA_VER=%%~v"
)
if not defined JAVA_VER goto :fail_java_version
if not "%JAVA_VER:~0,2%"=="17" goto :fail_java_version

rem ---------------------------------------------------------------
rem 2. Gradle already installed and verified?
rem ---------------------------------------------------------------
if not exist "%GRADLE_BAT%" goto :install_gradle
if exist "%VERIFIED_MARK%" goto :run_gradle
echo [ERROR] "%GRADLE_HOME%" exists but was not installed by this script.
echo         For safety it will not be used. Delete that folder and run again.
set "RC=1"
goto :finish

:install_gradle
rem ---------------------------------------------------------------
rem 3. Check built-in tools
rem ---------------------------------------------------------------
for %%t in (curl.exe certutil.exe tar.exe) do (
    if not exist "%SYS32%\%%t" goto :fail_tools
)

rem ---------------------------------------------------------------
rem 4. Download (HTTPS only) to a temporary file
rem ---------------------------------------------------------------
if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"
if errorlevel 1 goto :fail_mkdir

set "TMP_ZIP=%BASE_DIR%\gradle-%GRADLE_VERSION%-bin.zip.part"
set "STAGING=%BASE_DIR%\staging-%RANDOM%%RANDOM%"
if exist "%TMP_ZIP%" del /f /q "%TMP_ZIP%" >nul 2>nul

echo.
echo [Nexus Defense] Downloading Gradle %GRADLE_VERSION% from services.gradle.org ...
"%SYS32%\curl.exe" --fail --silent --show-error --location --proto "=https" --proto-redir "=https" --tlsv1.2 --max-redirs 5 --retry 2 --connect-timeout 30 --output "%TMP_ZIP%" "%GRADLE_URL%"
if errorlevel 1 goto :fail_download

rem ---------------------------------------------------------------
rem 5. Verify SHA-256 BEFORE extracting anything
rem ---------------------------------------------------------------
set "ACTUAL_SHA256="
for /f "skip=1 tokens=* delims=" %%h in ('""%SYS32%\certutil.exe" -hashfile "%TMP_ZIP%" SHA256"') do (
    if not defined ACTUAL_SHA256 set "ACTUAL_SHA256=%%h"
)
if not defined ACTUAL_SHA256 goto :fail_hash
set "ACTUAL_SHA256=%ACTUAL_SHA256: =%"
if /i not "%ACTUAL_SHA256%"=="%GRADLE_SHA256%" goto :fail_hash_mismatch
echo [Nexus Defense] SHA-256 verified.

rem ---------------------------------------------------------------
rem 6. Extract into a staging folder, then move into place
rem ---------------------------------------------------------------
mkdir "%STAGING%"
if errorlevel 1 goto :fail_mkdir
"%SYS32%\tar.exe" -xf "%TMP_ZIP%" -C "%STAGING%"
if errorlevel 1 goto :fail_extract
if not exist "%STAGING%\gradle-%GRADLE_VERSION%\bin\gradle.bat" goto :fail_extract

move "%STAGING%\gradle-%GRADLE_VERSION%" "%GRADLE_HOME%" >nul
if errorlevel 1 goto :fail_extract

echo verified> "%VERIFIED_MARK%"
rd /s /q "%STAGING%" >nul 2>nul
del /f /q "%TMP_ZIP%" >nul 2>nul
echo [Nexus Defense] Gradle %GRADLE_VERSION% installed to "%GRADLE_HOME%"

rem ---------------------------------------------------------------
rem 7. Run Gradle
rem ---------------------------------------------------------------
:run_gradle
echo.
echo [Nexus Defense] Java %JAVA_VER% / Gradle %GRADLE_VERSION%
if "%~1"=="" (
    call "%GRADLE_BAT%" build
) else (
    call "%GRADLE_BAT%" %*
)
set "BUILD_EXIT=%ERRORLEVEL%"

echo.
if "%BUILD_EXIT%"=="0" (
    echo [Nexus Defense] Build finished. Output folder: build\libs
) else (
    echo [Nexus Defense] Build FAILED with exit code %BUILD_EXIT%.
)
set "RC=%BUILD_EXIT%"
goto :finish

rem ---------------------------------------------------------------
rem  Error handlers
rem ---------------------------------------------------------------
:fail_cd
echo [ERROR] Could not change to the project folder.
set "RC=1"
goto :finish

:fail_no_project
echo [ERROR] build.gradle not found. Put gradlew.bat in the project root.
set "RC=1"
goto :finish

:fail_java_missing
echo [ERROR] Java 17 was not found in JAVA_HOME, PATH or standard install folders.
echo         Install JDK 17 (for example Eclipse Temurin 17) and run this file again.
set "RC=1"
goto :finish

:fail_java_version
echo [ERROR] Java 17 is required. Detected version: %JAVA_VER%
echo         Java used: %JAVA_EXE%
echo         Set JAVA_HOME to a JDK 17 folder and run this file again.
set "RC=1"
goto :finish

:fail_tools
echo [ERROR] curl.exe, certutil.exe or tar.exe is missing from System32.
echo         Windows 10 version 1803 or later is required.
set "RC=1"
goto :finish

:fail_mkdir
echo [ERROR] Could not create a folder under "%BASE_DIR%".
set "RC=1"
goto :finish

:fail_download
echo [ERROR] Download failed. Check your internet connection or proxy and try again.
if exist "%TMP_ZIP%" del /f /q "%TMP_ZIP%" >nul 2>nul
set "RC=1"
goto :finish

:fail_hash
echo [ERROR] Could not calculate SHA-256 of the downloaded file.
if exist "%TMP_ZIP%" del /f /q "%TMP_ZIP%" >nul 2>nul
set "RC=1"
goto :finish

:fail_hash_mismatch
echo [ERROR] SHA-256 MISMATCH. The downloaded file was NOT used and was deleted.
echo         expected: %GRADLE_SHA256%
echo         actual  : %ACTUAL_SHA256%
if exist "%TMP_ZIP%" del /f /q "%TMP_ZIP%" >nul 2>nul
set "RC=1"
goto :finish

:fail_extract
echo [ERROR] Could not extract Gradle. Nothing was installed.
if exist "%STAGING%" rd /s /q "%STAGING%" >nul 2>nul
if exist "%TMP_ZIP%" del /f /q "%TMP_ZIP%" >nul 2>nul
set "RC=1"
goto :finish

:finish
if defined PAUSE_AT_END (
    echo.
    pause
)
exit /b %RC%
